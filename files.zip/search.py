"""app/routes/search.py — FTS5 search and autocomplete endpoints."""
from __future__ import annotations
from flask import Blueprint, jsonify, request
from app.auth import get_current_user, require_auth
from app.services.search_engine import search_engine

search_bp = Blueprint("search", __name__, url_prefix="/api/v1/search")

@search_bp.route("", methods=["GET"])
@require_auth
def search():
    user = get_current_user()
    q            = request.args.get("q", "").strip()
    entity_types = request.args.getlist("type") or None
    limit        = request.args.get("limit", 20, type=int)
    offset       = request.args.get("offset", 0, type=int)

    if not q or len(q) < 2:
        return jsonify({"error": "q must be at least 2 characters"}), 422

    if not search_engine._db:
        return jsonify({"error": "Search engine not initialised"}), 503

    results, total = search_engine.search(
        query=q, company_id=user.company_id,
        entity_types=entity_types, limit=min(100, limit), offset=max(0, offset))

    return jsonify({"results": results, "total": total,
                    "query": q, "entity_types": entity_types or "all"}), 200


@search_bp.route("/suggest", methods=["GET"])
@require_auth
def suggest():
    user = get_current_user()
    q           = request.args.get("q", "").strip()
    entity_type = request.args.get("type", None)
    limit       = request.args.get("limit", 10, type=int)

    if not q:
        return jsonify({"suggestions": []}), 200

    if not search_engine._db:
        return jsonify({"suggestions": []}), 200

    suggestions = search_engine.suggest(
        query=q, company_id=user.company_id,
        entity_type=entity_type, limit=min(20, limit))

    return jsonify({"suggestions": suggestions, "query": q}), 200
