"""
app/services/pagination.py — Shared pagination service for all list endpoints.
"""
from __future__ import annotations
import math
from typing import Any, Callable, Optional
from sqlalchemy.orm import Query

DEFAULT_PAGE, DEFAULT_PER_PAGE, MAX_PER_PAGE, MIN_PER_PAGE = 1, 20, 100, 1


def paginate(
    query: Query,
    args: Any,
    sort_allowlist: set[str],
    default_sort: str = "created_at",
    default_order: str = "desc",
) -> tuple[list, int]:
    """Apply sort + offset + limit. Returns (items, total)."""
    page     = _int(args.get("page"),     DEFAULT_PAGE,     1,           None)
    per_page = _int(args.get("per_page"), DEFAULT_PER_PAGE, MIN_PER_PAGE, MAX_PER_PAGE)
    sort     = v if (v := args.get("sort")) and v in sort_allowlist else default_sort
    order    = args.get("order", default_order).lower()
    if order not in ("asc", "desc"):
        order = default_order

    entity = query.column_descriptions[0]["entity"]
    col    = getattr(entity, sort, None) or getattr(entity, default_sort)
    query  = query.order_by(col.desc() if order == "desc" else col.asc())

    total = query.count()
    items = query.offset((page - 1) * per_page).limit(per_page).all()
    return items, total


def build_response(
    items: list,
    total: int,
    args: Any,
    serializer: Optional[Callable] = None,
) -> dict:
    """Return standard paginated response dict."""
    page     = _int(args.get("page"),     DEFAULT_PAGE,     1,           None)
    per_page = _int(args.get("per_page"), DEFAULT_PER_PAGE, MIN_PER_PAGE, MAX_PER_PAGE)
    pages    = max(1, math.ceil(total / per_page))
    return {
        "items":    [serializer(i) for i in items] if serializer else items,
        "total":    total,
        "page":     page,
        "per_page": per_page,
        "pages":    pages,
        "has_next": page < pages,
        "has_prev": page > 1,
    }


def _int(value: Any, default: int, lo: Optional[int], hi: Optional[int]) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        n = default
    if lo is not None: n = max(n, lo)
    if hi is not None: n = min(n, hi)
    return n
