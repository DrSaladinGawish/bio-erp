"""app/services/search_engine.py — FTS5 multi-entity search engine."""
from __future__ import annotations
import logging, re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from sqlalchemy import text
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

@dataclass
class _EntityConfig:
    entity_type: str; fts_table: str; source_table: str
    search_columns: List[str]; id_column: str = "id"; label_column: str = "name"

class SearchEngine:
    def __init__(self, db_session: Session):
        self._db = db_session
        self._registry: Dict[str, _EntityConfig] = {}

    def register(self, entity_type: str, fts_table: str, source_table: str,
                 search_columns: List[str], id_column: str = "id",
                 label_column: str = "name") -> None:
        self._registry[entity_type] = _EntityConfig(
            entity_type=entity_type, fts_table=fts_table, source_table=source_table,
            search_columns=search_columns, id_column=id_column, label_column=label_column)
        logger.info("SearchEngine: registered %r → %r", entity_type, fts_table)

    def search(self, query: str, company_id: int,
               entity_types: Optional[List[str]] = None,
               limit: int = 20, offset: int = 0) -> Tuple[List[dict], int]:
        limit = min(100, max(1, limit)); offset = max(0, offset)
        safe_q = _sanitise(query)
        if not safe_q: return [], 0
        types = [t for t in (entity_types or list(self._registry)) if t in self._registry]
        if not types: return [], 0
        results = []
        for et in types:
            results.extend(self._search_one(self._registry[et], safe_q, company_id))
        results.sort(key=lambda r: r["rank"])
        return results[offset: offset + limit], len(results)

    def _search_one(self, cfg: _EntityConfig, safe_q: str, company_id: int) -> List[dict]:
        sql = text(f"""
            SELECT :et AS entity_type, f.entity_id,
                   f.{cfg.label_column} AS label,
                   snippet({cfg.fts_table}, 0, '<mark>', '</mark>', '…', 12) AS snippet,
                   bm25({cfg.fts_table}) AS rank
            FROM {cfg.fts_table} f
            WHERE {cfg.fts_table} MATCH :q AND f.company_id = :cid
            ORDER BY rank LIMIT 50
        """)
        try:
            rows = self._db.execute(sql, {"et": cfg.entity_type, "q": safe_q,
                                          "cid": str(company_id)}).fetchall()
            return [{"entity_type": r.entity_type, "entity_id": r.entity_id,
                     "label": r.label, "snippet": r.snippet or "",
                     "rank": r.rank or 0.0} for r in rows]
        except Exception as exc:
            logger.error("FTS5 error on %s: %s", cfg.fts_table, exc); return []

    def suggest(self, query: str, company_id: int,
                entity_type: Optional[str] = None, limit: int = 10) -> List[str]:
        limit = min(20, max(1, limit))
        safe_pfx = _sanitise(query, prefix=True)
        if not safe_pfx: return []
        types = ([entity_type] if entity_type else list(self._registry))
        types = [t for t in types if t in self._registry]
        suggestions: List[str] = []
        for et in types:
            cfg = self._registry[et]
            try:
                rows = self._db.execute(text(f"""
                    SELECT DISTINCT f.{cfg.label_column} AS label
                    FROM {cfg.fts_table} f
                    WHERE {cfg.fts_table} MATCH :q AND f.company_id = :cid LIMIT :lim
                """), {"q": safe_pfx, "cid": str(company_id), "lim": limit}).fetchall()
                suggestions.extend(r.label for r in rows if r.label)
            except Exception as exc:
                logger.error("Suggest error on %s: %s", cfg.fts_table, exc)
        seen: set = set()
        return [s for s in suggestions if not (seen.add(s) or s in seen)][:limit]

    def reindex(self, entity_type: str) -> int:
        if entity_type not in self._registry:
            raise ValueError(f"Unknown entity_type: {entity_type!r}")
        cfg = self._registry[entity_type]
        try:
            self._db.execute(text(f"INSERT INTO {cfg.fts_table}({cfg.fts_table}) VALUES('rebuild')"))
            self._db.commit()
            return self._db.execute(text(f"SELECT count(*) FROM {cfg.fts_table}")).scalar() or 0
        except Exception as exc:
            self._db.rollback(); logger.error("Reindex failed: %s", exc); raise

def _sanitise(raw: str, prefix: bool = False) -> str:
    if not raw or not isinstance(raw, str): return ""
    cleaned = re.sub(r'[^\w\s\-]', ' ', raw.strip()[:200], flags=re.UNICODE)
    tokens  = [t.strip() for t in cleaned.split() if t.strip()]
    if not tokens: return ""
    if prefix:
        return " ".join(f'"{t}"' for t in tokens[:-1]) + f' "{tokens[-1]}"*'
    return " ".join(f'"{t}"' for t in tokens)

# Singleton — wire db session in app factory after db.init_app(app)
search_engine = SearchEngine(db_session=None)  # type: ignore[arg-type]
