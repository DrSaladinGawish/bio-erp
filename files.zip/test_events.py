"""
tests/test_events.py
=====================
Tests for app/routes/events.py

Coverage:
* CRUD with full validation (event_code uniqueness, date ordering, status enum)
* Pagination + filtering (status, date range, q search)
* Status lifecycle (DRAFT → PLANNING → ACTIVE → COMPLETED → CANCELLED)
* Optimistic locking (409 on stale version)
* Multi-tenancy isolation (Company A cannot access Company B's events)
* Soft delete (deleted events excluded from list + get)
* Permission gating (READ_ONLY cannot create/update/delete)
* start_date < end_date enforcement
* event_code uniqueness per company
"""
from __future__ import annotations
import pytest
from datetime import date, timedelta


# ── helpers ────────────────────────────────────────────────────────

def _post_event(client, headers, payload):
    return client.post("/api/v1/events", json=payload, headers=headers,
                       content_type="application/json")


def _valid_event(suffix: str = "001") -> dict:
    today = date.today()
    return {
        "event_code":          f"EVT-{suffix}",
        "event_name":          f"Test Event {suffix}",
        "description":         "Integration test event",
        "venue_name":          "Main Hall",
        "city":                "Riyadh",
        "start_date":          today.isoformat(),
        "end_date":            (today + timedelta(days=2)).isoformat(),
        "estimated_attendees": 100,
        "status":              "DRAFT",
    }


# ═══════════════════════════════════════════════════════════════════
# CREATE
# ═══════════════════════════════════════════════════════════════════

class TestEventCreate:

    def test_create_success_returns_201(self, client, auth_headers_a):
        resp = _post_event(client, auth_headers_a, _valid_event())
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["event_code"] == "EVT-001"
        assert data["status"]     == "DRAFT"
        assert "version" in data
        assert data["version"] == 0

    def test_event_code_must_be_unique_per_company(self, client, auth_headers_a):
        _post_event(client, auth_headers_a, _valid_event("DUP"))
        resp = _post_event(client, auth_headers_a, _valid_event("DUP"))
        assert resp.status_code == 409
        assert "duplicate" in resp.get_json()["error"].lower()

    def test_same_code_allowed_in_different_company(self, client,
                                                     auth_headers_a, auth_headers_b):
        r1 = _post_event(client, auth_headers_a, _valid_event("CROSS"))
        r2 = _post_event(client, auth_headers_b, _valid_event("CROSS"))
        assert r1.status_code == 201
        assert r2.status_code == 201

    def test_end_date_before_start_date_fails(self, client, auth_headers_a):
        ev = _valid_event("BAD-DATE")
        ev["start_date"] = "2024-12-31"
        ev["end_date"]   = "2024-12-01"
        resp = _post_event(client, auth_headers_a, ev)
        assert resp.status_code == 422
        data = resp.get_json()
        assert "end_date" in data.get("fields", {}) or "date" in data.get("error", "").lower()

    def test_negative_attendees_fails(self, client, auth_headers_a):
        ev = _valid_event("NEG-ATT")
        ev["estimated_attendees"] = -1
        resp = _post_event(client, auth_headers_a, ev)
        assert resp.status_code == 422

    def test_invalid_status_fails(self, client, auth_headers_a):
        ev = _valid_event("BAD-STATUS")
        ev["status"] = "UNKNOWN"
        resp = _post_event(client, auth_headers_a, ev)
        assert resp.status_code == 422

    def test_event_code_alphanumeric_dash_only(self, client, auth_headers_a):
        ev = _valid_event()
        ev["event_code"] = "EVT <script>"
        resp = _post_event(client, auth_headers_a, ev)
        assert resp.status_code == 422

    def test_event_code_too_short_fails(self, client, auth_headers_a):
        ev = _valid_event(); ev["event_code"] = "AB"
        assert _post_event(client, auth_headers_a, ev).status_code == 422

    def test_missing_required_field_fails(self, client, auth_headers_a):
        ev = _valid_event(); del ev["event_name"]
        assert _post_event(client, auth_headers_a, ev).status_code == 422

    def test_read_only_cannot_create(self, client, auth_headers_readonly):
        assert _post_event(client, auth_headers_readonly, _valid_event("RO")).status_code == 403


# ═══════════════════════════════════════════════════════════════════
# LIST
# ═══════════════════════════════════════════════════════════════════

class TestEventList:

    def test_list_returns_paginated(self, client, auth_headers_a):
        for i in range(3):
            _post_event(client, auth_headers_a, _valid_event(f"LIST-{i}"))
        resp = client.get("/api/v1/events?per_page=2", headers=auth_headers_a)
        assert resp.status_code == 200
        data = resp.get_json()
        assert "items"    in data
        assert "total"    in data
        assert "has_next" in data
        assert len(data["items"]) <= 2

    def test_filter_by_status(self, client, auth_headers_a):
        _post_event(client, auth_headers_a, _valid_event("FSTATUS"))
        resp = client.get("/api/v1/events?status=DRAFT", headers=auth_headers_a)
        assert resp.status_code == 200
        for ev in resp.get_json()["items"]:
            assert ev["status"] == "DRAFT"

    def test_search_q_filters_by_name(self, client, auth_headers_a):
        ev = _valid_event("FINDME"); ev["event_name"] = "Unique Searchable Name 9z3x"
        _post_event(client, auth_headers_a, ev)
        resp = client.get("/api/v1/events?q=9z3x", headers=auth_headers_a)
        assert resp.status_code == 200
        items = resp.get_json()["items"]
        assert any("9z3x" in i["event_name"] for i in items)

    def test_company_isolation_in_list(self, client, auth_headers_a, auth_headers_b):
        ev = _valid_event("ISOLATED"); ev["event_name"] = "Company A Only Event"
        _post_event(client, auth_headers_a, ev)
        resp_b = client.get("/api/v1/events", headers=auth_headers_b)
        names = [i["event_name"] for i in resp_b.get_json()["items"]]
        assert "Company A Only Event" not in names

    def test_deleted_events_excluded(self, client, auth_headers_a):
        r = _post_event(client, auth_headers_a, _valid_event("DELTEST"))
        ev_id = r.get_json()["id"]
        version = r.get_json()["version"]
        client.delete(f"/api/v1/events/{ev_id}",
                      json={"confirm_name": "Test Event DELTEST", "version": version},
                      headers=auth_headers_a)
        resp = client.get("/api/v1/events", headers=auth_headers_a)
        ids = [i["id"] for i in resp.get_json()["items"]]
        assert ev_id not in ids


# ═══════════════════════════════════════════════════════════════════
# GET single
# ═══════════════════════════════════════════════════════════════════

class TestEventGet:

    def test_get_own_event(self, client, auth_headers_a):
        r = _post_event(client, auth_headers_a, _valid_event("GET1"))
        ev_id = r.get_json()["id"]
        resp = client.get(f"/api/v1/events/{ev_id}", headers=auth_headers_a)
        assert resp.status_code == 200
        assert resp.get_json()["id"] == ev_id

    def test_get_other_tenant_event_returns_404(self, client, auth_headers_a, auth_headers_b):
        r = _post_event(client, auth_headers_a, _valid_event("XGET"))
        ev_id = r.get_json()["id"]
        resp = client.get(f"/api/v1/events/{ev_id}", headers=auth_headers_b)
        assert resp.status_code == 404

    def test_get_nonexistent_returns_404(self, client, auth_headers_a):
        assert client.get("/api/v1/events/999999", headers=auth_headers_a).status_code == 404


# ═══════════════════════════════════════════════════════════════════
# UPDATE
# ═══════════════════════════════════════════════════════════════════

class TestEventUpdate:

    def test_update_success(self, client, auth_headers_a):
        r = _post_event(client, auth_headers_a, _valid_event("UPD1"))
        ev = r.get_json()
        resp = client.put(f"/api/v1/events/{ev['id']}",
                          json={"event_name": "Updated Name", "version": ev["version"]},
                          headers=auth_headers_a)
        assert resp.status_code == 200
        assert resp.get_json()["event_name"] == "Updated Name"
        assert resp.get_json()["version"] == ev["version"] + 1

    def test_optimistic_lock_conflict_returns_409(self, client, auth_headers_a):
        r = _post_event(client, auth_headers_a, _valid_event("LOCK1"))
        ev = r.get_json()
        # First update succeeds
        client.put(f"/api/v1/events/{ev['id']}",
                   json={"event_name": "First Update", "version": ev["version"]},
                   headers=auth_headers_a)
        # Second update with stale version fails
        resp = client.put(f"/api/v1/events/{ev['id']}",
                          json={"event_name": "Stale Update", "version": ev["version"]},
                          headers=auth_headers_a)
        assert resp.status_code == 409

    def test_cannot_update_other_tenant_event(self, client, auth_headers_a, auth_headers_b):
        r = _post_event(client, auth_headers_a, _valid_event("XUPD"))
        ev = r.get_json()
        resp = client.put(f"/api/v1/events/{ev['id']}",
                          json={"event_name": "Hacked", "version": ev["version"]},
                          headers=auth_headers_b)
        assert resp.status_code == 404


# ═══════════════════════════════════════════════════════════════════
# DELETE
# ═══════════════════════════════════════════════════════════════════

class TestEventDelete:

    def test_delete_requires_typed_confirmation(self, client, auth_headers_a):
        r = _post_event(client, auth_headers_a, _valid_event("DEL2"))
        ev = r.get_json()
        resp = client.delete(f"/api/v1/events/{ev['id']}",
                             json={"confirm_name": "WRONG NAME", "version": ev["version"]},
                             headers=auth_headers_a)
        assert resp.status_code == 422

    def test_delete_with_correct_confirmation(self, client, auth_headers_a):
        r = _post_event(client, auth_headers_a, _valid_event("DEL3"))
        ev = r.get_json()
        resp = client.delete(f"/api/v1/events/{ev['id']}",
                             json={"confirm_name": ev["event_name"], "version": ev["version"]},
                             headers=auth_headers_a)
        assert resp.status_code == 200
        # Verify soft-deleted
        get_resp = client.get(f"/api/v1/events/{ev['id']}", headers=auth_headers_a)
        assert get_resp.status_code == 404

    def test_read_only_cannot_delete(self, client, auth_headers_a, auth_headers_readonly):
        r = _post_event(client, auth_headers_a, _valid_event("RODEL"))
        ev = r.get_json()
        resp = client.delete(f"/api/v1/events/{ev['id']}",
                             json={"confirm_name": ev["event_name"], "version": ev["version"]},
                             headers=auth_headers_readonly)
        assert resp.status_code == 403
