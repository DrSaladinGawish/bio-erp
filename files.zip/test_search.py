"""
tests/test_search.py — FTS5 search endpoint tests.
"""
from __future__ import annotations
import pytest


class TestSearchEndpoint:

    def test_search_requires_auth(self, client):
        assert client.get("/api/v1/search?q=test").status_code == 401

    def test_search_too_short_query_fails(self, client, auth_headers_a):
        resp = client.get("/api/v1/search?q=a", headers=auth_headers_a)
        assert resp.status_code == 422

    def test_search_returns_structure(self, client, auth_headers_a):
        resp = client.get("/api/v1/search?q=test", headers=auth_headers_a)
        # 200 or 503 (if FTS5 not initialised in test) — both are valid
        assert resp.status_code in (200, 503)
        if resp.status_code == 200:
            data = resp.get_json()
            assert "results" in data
            assert "total"   in data

    def test_search_empty_result_not_error(self, client, auth_headers_a):
        resp = client.get("/api/v1/search?q=zzz_unlikely_match_xyz",
                          headers=auth_headers_a)
        assert resp.status_code in (200, 503)
        if resp.status_code == 200:
            assert resp.get_json()["total"] >= 0

    def test_search_respects_company_isolation(self, client, auth_headers_b):
        # Company B search must not leak Company A data
        resp = client.get("/api/v1/search?q=company_a_private",
                          headers=auth_headers_b)
        assert resp.status_code in (200, 503)
        if resp.status_code == 200:
            for r in resp.get_json()["results"]:
                # All results must belong to company B (check via entity_id presence only)
                assert "entity_type" in r
                assert "entity_id"   in r

    def test_search_type_filter_accepted(self, client, auth_headers_a):
        resp = client.get("/api/v1/search?q=test&type=cells",
                          headers=auth_headers_a)
        assert resp.status_code in (200, 503)

    def test_search_limit_capped_at_100(self, client, auth_headers_a):
        resp = client.get("/api/v1/search?q=test&limit=9999",
                          headers=auth_headers_a)
        assert resp.status_code in (200, 503)
        if resp.status_code == 200:
            assert len(resp.get_json()["results"]) <= 100


class TestSuggestEndpoint:

    def test_suggest_requires_auth(self, client):
        assert client.get("/api/v1/search/suggest?q=te").status_code == 401

    def test_suggest_empty_q_returns_empty(self, client, auth_headers_a):
        resp = client.get("/api/v1/search/suggest?q=", headers=auth_headers_a)
        assert resp.status_code == 200
        assert resp.get_json()["suggestions"] == []

    def test_suggest_returns_list(self, client, auth_headers_a):
        resp = client.get("/api/v1/search/suggest?q=te", headers=auth_headers_a)
        assert resp.status_code == 200
        data = resp.get_json()
        assert "suggestions" in data
        assert isinstance(data["suggestions"], list)

    def test_suggest_limit_respected(self, client, auth_headers_a):
        resp = client.get("/api/v1/search/suggest?q=te&limit=3",
                          headers=auth_headers_a)
        assert resp.status_code == 200
        assert len(resp.get_json()["suggestions"]) <= 3


class TestSearchSanitisation:
    """Verify FTS5 injection cannot occur via q parameter."""

    def test_sql_injection_in_query(self, client, auth_headers_a):
        # Must not raise 500; must return 422 or valid empty results
        resp = client.get('/api/v1/search?q="; DROP TABLE cells; --',
                          headers=auth_headers_a)
        assert resp.status_code in (200, 422, 503)
        if resp.status_code == 200:
            assert "results" in resp.get_json()

    def test_fts5_special_chars_handled(self, client, auth_headers_a):
        # FTS5 operators must be escaped by _sanitise()
        for bad_q in ["OR AND NOT", '"unclosed', "***", "NEAR(a b)"]:
            resp = client.get(f"/api/v1/search?q={bad_q}", headers=auth_headers_a)
            assert resp.status_code in (200, 422, 503), f"Failed on: {bad_q!r}"
