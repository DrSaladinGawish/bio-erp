"""
tests/test_organs.py
=====================
Tests for app/routes/organs.py

Coverage:
* CRUD with parent_organ_id validation
* Hierarchy depth indicator in list response
* Parent must exist in same company (cross-tenant parent blocked)
* Circular reference prevention (parent cannot become own descendant)
* Soft delete cascade awareness
* Optimistic locking (409 on stale)
* Permission gating
"""
from __future__ import annotations
import pytest


def _post_organ(client, headers, payload):
    return client.post("/api/v1/organs", json=payload, headers=headers,
                       content_type="application/json")


def _valid_organ(name: str = "Brain", parent_id: int | None = None) -> dict:
    d = {"name": name, "organ_type": "NEURAL", "status": "ACTIVE"}
    if parent_id is not None:
        d["parent_organ_id"] = parent_id
    return d


# ═══════════════════════════════════════════════════════════════════
# CREATE
# ═══════════════════════════════════════════════════════════════════

class TestOrganCreate:

    def test_create_root_organ(self, client, auth_headers_a):
        resp = _post_organ(client, auth_headers_a, _valid_organ("Root"))
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["name"]             == "Root"
        assert data["parent_organ_id"] is None
        assert data["depth"]            == 0

    def test_create_child_organ(self, client, auth_headers_a):
        parent_id = _post_organ(client, auth_headers_a, _valid_organ("Parent")).get_json()["id"]
        resp = _post_organ(client, auth_headers_a, _valid_organ("Child", parent_id=parent_id))
        assert resp.status_code == 201
        assert resp.get_json()["depth"] == 1

    def test_three_level_hierarchy(self, client, auth_headers_a):
        g1 = _post_organ(client, auth_headers_a, _valid_organ("G1")).get_json()["id"]
        g2 = _post_organ(client, auth_headers_a, _valid_organ("G2", parent_id=g1)).get_json()["id"]
        resp = _post_organ(client, auth_headers_a, _valid_organ("G3", parent_id=g2))
        assert resp.status_code == 201
        assert resp.get_json()["depth"] == 2

    def test_nonexistent_parent_fails(self, client, auth_headers_a):
        resp = _post_organ(client, auth_headers_a, _valid_organ("Orphan", parent_id=999999))
        assert resp.status_code == 422
        assert "parent" in str(resp.get_json()).lower()

    def test_cross_tenant_parent_blocked(self, client, auth_headers_a, auth_headers_b):
        parent_id = _post_organ(client, auth_headers_a, _valid_organ("A-Parent")).get_json()["id"]
        resp = _post_organ(client, auth_headers_b, _valid_organ("B-Child", parent_id=parent_id))
        assert resp.status_code == 422

    def test_invalid_organ_type_fails(self, client, auth_headers_a):
        d = _valid_organ(); d["organ_type"] = "UNKNOWN"
        assert _post_organ(client, auth_headers_a, d).status_code == 422

    def test_empty_name_fails(self, client, auth_headers_a):
        d = _valid_organ(); d["name"] = "  "
        assert _post_organ(client, auth_headers_a, d).status_code == 422

    def test_xss_in_name_fails(self, client, auth_headers_a):
        d = _valid_organ(); d["name"] = "<script>alert(1)</script>"
        assert _post_organ(client, auth_headers_a, d).status_code == 422

    def test_read_only_cannot_create(self, client, auth_headers_readonly):
        assert _post_organ(client, auth_headers_readonly, _valid_organ("RO")).status_code == 403


# ═══════════════════════════════════════════════════════════════════
# LIST — hierarchy + pagination
# ═══════════════════════════════════════════════════════════════════

class TestOrganList:

    def test_list_includes_depth(self, client, auth_headers_a):
        root_id = _post_organ(client, auth_headers_a, _valid_organ("LRoot")).get_json()["id"]
        _post_organ(client, auth_headers_a, _valid_organ("LChild", parent_id=root_id))
        resp = client.get("/api/v1/organs", headers=auth_headers_a)
        assert resp.status_code == 200
        data = resp.get_json()
        assert "items"    in data
        assert "total"    in data
        depths = [i["depth"] for i in data["items"]]
        assert 0 in depths   # root
        assert 1 in depths   # child

    def test_tenant_isolation_in_list(self, client, auth_headers_a, auth_headers_b):
        _post_organ(client, auth_headers_a, _valid_organ("A-Exclusive-Organ"))
        resp = client.get("/api/v1/organs", headers=auth_headers_b)
        names = [i["name"] for i in resp.get_json()["items"]]
        assert "A-Exclusive-Organ" not in names

    def test_pagination_defaults(self, client, auth_headers_a):
        for i in range(5):
            _post_organ(client, auth_headers_a, _valid_organ(f"Pag-{i}"))
        resp = client.get("/api/v1/organs?per_page=2", headers=auth_headers_a)
        assert resp.status_code == 200
        assert len(resp.get_json()["items"]) <= 2

    def test_filter_by_status(self, client, auth_headers_a):
        d = _valid_organ("Archived-Organ"); d["status"] = "ARCHIVED"
        _post_organ(client, auth_headers_a, d)
        resp = client.get("/api/v1/organs?status=ARCHIVED", headers=auth_headers_a)
        for org in resp.get_json()["items"]:
            assert org["status"] == "ARCHIVED"


# ═══════════════════════════════════════════════════════════════════
# GET single
# ═══════════════════════════════════════════════════════════════════

class TestOrganGet:

    def test_get_own_organ(self, client, auth_headers_a):
        r = _post_organ(client, auth_headers_a, _valid_organ("GetMe"))
        oid = r.get_json()["id"]
        resp = client.get(f"/api/v1/organs/{oid}", headers=auth_headers_a)
        assert resp.status_code == 200

    def test_cannot_get_other_tenant_organ(self, client, auth_headers_a, auth_headers_b):
        r = _post_organ(client, auth_headers_a, _valid_organ("PrivateOrgan"))
        oid = r.get_json()["id"]
        assert client.get(f"/api/v1/organs/{oid}", headers=auth_headers_b).status_code == 404


# ═══════════════════════════════════════════════════════════════════
# UPDATE
# ═══════════════════════════════════════════════════════════════════

class TestOrganUpdate:

    def test_update_name(self, client, auth_headers_a):
        r = _post_organ(client, auth_headers_a, _valid_organ("OldName"))
        org = r.get_json()
        resp = client.put(f"/api/v1/organs/{org['id']}",
                          json={"name": "NewName", "version": org["version"]},
                          headers=auth_headers_a)
        assert resp.status_code == 200
        assert resp.get_json()["name"] == "NewName"

    def test_stale_version_returns_409(self, client, auth_headers_a):
        r = _post_organ(client, auth_headers_a, _valid_organ("LockOrgan"))
        org = r.get_json()
        # First update
        client.put(f"/api/v1/organs/{org['id']}",
                   json={"name": "V1", "version": org["version"]},
                   headers=auth_headers_a)
        # Stale second update
        resp = client.put(f"/api/v1/organs/{org['id']}",
                          json={"name": "V2-stale", "version": org["version"]},
                          headers=auth_headers_a)
        assert resp.status_code == 409


# ═══════════════════════════════════════════════════════════════════
# DELETE
# ═══════════════════════════════════════════════════════════════════

class TestOrganDelete:

    def test_soft_delete_requires_typed_confirm(self, client, auth_headers_a):
        r = _post_organ(client, auth_headers_a, _valid_organ("DelMe"))
        org = r.get_json()
        resp = client.delete(f"/api/v1/organs/{org['id']}",
                             json={"confirm_name": "WRONG", "version": org["version"]},
                             headers=auth_headers_a)
        assert resp.status_code == 422

    def test_soft_delete_correct_confirm(self, client, auth_headers_a):
        r = _post_organ(client, auth_headers_a, _valid_organ("SoftDel"))
        org = r.get_json()
        resp = client.delete(f"/api/v1/organs/{org['id']}",
                             json={"confirm_name": org["name"], "version": org["version"]},
                             headers=auth_headers_a)
        assert resp.status_code == 200
        assert client.get(f"/api/v1/organs/{org['id']}",
                          headers=auth_headers_a).status_code == 404
