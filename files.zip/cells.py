"""
app/routes/cells.py — Cell entity CRUD + bulk creation.

Auth: @require_auth + @require_permission using actual enum members.
      get_current_user() is the correct function (not current_user()).
All queries: company_id = user.company_id AND deleted_at IS NULL.
All updates: version check → 409 on stale update.
Destructive actions: typed confirmation required (no OK/Cancel).
"""
from __future__ import annotations

import uuid
from datetime import UTC, datetime

from flask import Blueprint, jsonify, request
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import or_
from sqlalchemy.exc import IntegrityError

from app.auth import Permission, get_current_user, require_auth, require_permission
from app.database import get_db
from app.services.pagination import build_response, paginate

cells_bp = Blueprint("cells", __name__, url_prefix="/api/v1/cells")

_CELL_TYPES    = {"NEURON", "GLIA", "MUSCLE", "EPITHELIAL", "STEM"}
_CELL_STATUSES = {"DRAFT", "ACTIVE", "SUSPENDED", "ARCHIVED"}
_SORT_COLS     = {"created_at", "updated_at", "name", "status", "cell_type", "capacity"}
_UNSAFE        = set("<>&\"'")


def _clean(v: str, max_len: int) -> str:
    v = v.strip()
    if any(c in v for c in _UNSAFE):
        raise ValueError("Field contains forbidden characters: < > & \" '")
    if len(v) > max_len:
        raise ValueError(f"Maximum {max_len} characters")
    return v


# ── Schemas ────────────────────────────────────────────────────────────────

class CellCreate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    name:        str          = Field(..., min_length=1)
    cell_type:   str
    organ_id:    int
    capacity:    int          = Field(0, ge=0, le=10_000)
    status:      str          = "DRAFT"
    description: str | None  = Field(None, max_length=2000)

    @field_validator("name")
    @classmethod
    def v_name(cls, v): return _clean(v, 255)

    @field_validator("cell_type")
    @classmethod
    def v_type(cls, v):
        v = v.upper()
        if v not in _CELL_TYPES:
            raise ValueError(f"Must be one of: {sorted(_CELL_TYPES)}")
        return v

    @field_validator("status")
    @classmethod
    def v_status(cls, v):
        v = v.upper()
        if v not in _CELL_STATUSES:
            raise ValueError(f"Must be one of: {sorted(_CELL_STATUSES)}")
        return v


class CellUpdate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    version:     int          = Field(..., description="Required for optimistic locking")
    name:        str | None   = None
    cell_type:   str | None   = None
    capacity:    int | None   = Field(None, ge=0, le=10_000)
    status:      str | None   = None
    description: str | None   = None

    @field_validator("name")
    @classmethod
    def v_name(cls, v): return _clean(v, 255) if v is not None else v

    @field_validator("cell_type")
    @classmethod
    def v_type(cls, v):
        if v is None: return v
        v = v.upper()
        if v not in _CELL_TYPES:
            raise ValueError(f"Must be one of: {sorted(_CELL_TYPES)}")
        return v

    @field_validator("status")
    @classmethod
    def v_status(cls, v):
        if v is None: return v
        v = v.upper()
        if v not in _CELL_STATUSES:
            raise ValueError(f"Must be one of: {sorted(_CELL_STATUSES)}")
        return v


class BulkCellCreate(BaseModel):
    items: list[CellCreate] = Field(..., min_length=1, max_length=1000)


# ── Helpers ────────────────────────────────────────────────────────────────

def _to_dict(cell) -> dict:
    return {
        "id":          cell.id,
        "company_id":  cell.company_id,
        "name":        cell.name,
        "cell_type":   cell.cell_type,
        "organ_id":    cell.organ_id,
        "capacity":    cell.capacity,
        "status":      cell.status,
        "description": cell.description,
        "created_by":  cell.created_by,
        "created_at":  cell.created_at.isoformat() if cell.created_at else None,
        "updated_at":  cell.updated_at.isoformat() if cell.updated_at else None,
        "version":     cell.version,
    }


def _validate(schema_cls, data: dict):
    from pydantic import ValidationError
    try:
        return schema_cls.model_validate(data), None
    except ValidationError as exc:
        errors = {}
        for e in exc.errors():
            field = ".".join(str(l) for l in e["loc"]) if e["loc"] else "__root__"
            errors[field] = e["msg"]
        return None, errors


def _verify_organ(db, organ_id: int, company_id: int):
    from app.models import Organ
    return (
        db.query(Organ)
        .filter(Organ.id == organ_id, Organ.company_id == company_id,
                Organ.deleted_at.is_(None))
        .first()
    )


# ── Endpoints ──────────────────────────────────────────────────────────────

@cells_bp.route("", methods=["POST"])
@require_auth
@require_permission(Permission.ENTITY_CREATE)
def create_cell():
    from app.models import Cell
    user = get_current_user()
    body, errors = _validate(CellCreate, request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 422

    db = get_db()
    if not _verify_organ(db, body.organ_id, user.company_id):
        return jsonify({"error": "Validation failed",
                        "fields": {"organ_id": "Organ not found"}}), 422

    cell = Cell(
        company_id=user.company_id, name=body.name, cell_type=body.cell_type,
        organ_id=body.organ_id, capacity=body.capacity, status=body.status,
        description=body.description, created_by=user.id, version=0,
    )
    db.add(cell)
    try:
        db.commit()
        db.refresh(cell)
    except IntegrityError:
        db.rollback()
        return jsonify({"error": "A cell with this name already exists in the organ"}), 409

    return jsonify(_to_dict(cell)), 201


@cells_bp.route("", methods=["GET"])
@require_auth
@require_permission(Permission.ENTITY_READ)
def list_cells():
    from app.models import Cell
    user = get_current_user()
    db   = get_db()

    query = db.query(Cell).filter(Cell.company_id == user.company_id,
                                   Cell.deleted_at.is_(None))

    if s := request.args.get("status"):
        query = query.filter(Cell.status == s.upper())
    if ct := request.args.get("cell_type"):
        query = query.filter(Cell.cell_type == ct.upper())
    if oid := request.args.get("organ_id", type=int):
        query = query.filter(Cell.organ_id == oid)
    if q := request.args.get("q", "").strip():
        p = f"%{q}%"
        query = query.filter(or_(Cell.name.ilike(p), Cell.description.ilike(p)))

    items, total = paginate(query, request.args, _SORT_COLS)
    return jsonify(build_response(items, total, request.args, _to_dict)), 200


@cells_bp.route("/<int:cell_id>", methods=["GET"])
@require_auth
@require_permission(Permission.ENTITY_READ)
def get_cell(cell_id: int):
    from app.models import Cell
    user = get_current_user()
    cell = get_db().query(Cell).filter(
        Cell.id == cell_id, Cell.company_id == user.company_id,
        Cell.deleted_at.is_(None)).first()
    if not cell:
        return jsonify({"error": "Cell not found"}), 404
    return jsonify(_to_dict(cell)), 200


@cells_bp.route("/<int:cell_id>", methods=["PUT"])
@require_auth
@require_permission(Permission.ENTITY_UPDATE)
def update_cell(cell_id: int):
    from app.models import Cell
    user = get_current_user()
    body, errors = _validate(CellUpdate, request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 422

    db   = get_db()
    cell = db.query(Cell).filter(
        Cell.id == cell_id, Cell.company_id == user.company_id,
        Cell.deleted_at.is_(None)).first()
    if not cell:
        return jsonify({"error": "Cell not found"}), 404
    if cell.version != body.version:
        return jsonify({"error": "Conflict: cell modified by another request. Reload and retry.",
                        "current_version": cell.version}), 409

    if body.name        is not None: cell.name        = body.name
    if body.cell_type   is not None: cell.cell_type   = body.cell_type
    if body.capacity    is not None: cell.capacity    = body.capacity
    if body.status      is not None: cell.status      = body.status
    if body.description is not None: cell.description = body.description
    cell.version   += 1
    cell.updated_at = datetime.now(UTC)

    db.commit()
    db.refresh(cell)
    return jsonify(_to_dict(cell)), 200


@cells_bp.route("/<int:cell_id>", methods=["DELETE"])
@require_auth
@require_permission(Permission.ENTITY_DELETE)
def delete_cell(cell_id: int):
    """Soft delete — requires typed confirmation (not OK/Cancel)."""
    from app.models import Cell
    user = get_current_user()
    body = request.get_json(silent=True) or {}
    db   = get_db()

    cell = db.query(Cell).filter(
        Cell.id == cell_id, Cell.company_id == user.company_id,
        Cell.deleted_at.is_(None)).first()
    if not cell:
        return jsonify({"error": "Cell not found"}), 404

    if body.get("confirm_name", "").strip() != cell.name:
        return jsonify({"error": "Confirmation failed",
                        "detail": f"Type '{cell.name}' exactly to confirm deletion"}), 422

    version = body.get("version")
    if version is None:
        return jsonify({"error": "version is required for deletion"}), 422
    if cell.version != int(version):
        return jsonify({"error": "Conflict: cell was modified. Reload and retry.",
                        "current_version": cell.version}), 409

    cell.deleted_at = datetime.now(UTC)
    cell.version   += 1
    db.commit()
    return jsonify({"status": "ok", "message": f"Cell '{cell.name}' deleted"}), 200


@cells_bp.route("/bulk", methods=["POST"])
@require_auth
@require_permission(Permission.ENTITY_CREATE)
def bulk_create_cells():
    """≤100 items: synchronous. >100 items: Celery task → 202 + job_id."""
    user = get_current_user()
    body, errors = _validate(BulkCellCreate, request.get_json(silent=True) or {})
    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 422

    if len(body.items) > 100:
        job_id = str(uuid.uuid4())
        try:
            from app.tasks import bulk_create_cells_task
            bulk_create_cells_task.apply_async(
                args=[user.company_id, user.id, [i.model_dump() for i in body.items]],
                task_id=job_id,
            )
        except ImportError:
            return jsonify({"error": "Celery not configured. Limit bulk to 100 items."}), 503

        return jsonify({"status": "accepted", "job_id": job_id,
                        "item_count": len(body.items)}), 202

    from app.models import Cell
    db         = get_db()
    successful = []
    failed     = []

    for idx, item in enumerate(body.items):
        if not _verify_organ(db, item.organ_id, user.company_id):
            failed.append({"index": idx, "error": f"organ_id {item.organ_id} not found"})
            continue
        cell = Cell(
            company_id=user.company_id, name=item.name, cell_type=item.cell_type,
            organ_id=item.organ_id, capacity=item.capacity, status=item.status,
            description=item.description, created_by=user.id, version=0,
        )
        db.add(cell)
        try:
            db.flush()
            successful.append({"index": idx, "id": cell.id, "name": cell.name})
        except IntegrityError:
            db.rollback()
            failed.append({"index": idx, "error": "Duplicate name in organ"})

    db.commit()
    status = 207 if failed else 201
    return jsonify({"status": "completed", "successful": len(successful),
                    "failed": len(failed), "results": successful, "errors": failed}), status
