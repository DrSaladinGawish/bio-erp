"""
tests/test_reports.py — Report generation endpoint tests.
"""
from __future__ import annotations
import pytest


def _post_report(client, headers, payload):
    return client.post("/api/v1/reports", json=payload, headers=headers,
                       content_type="application/json")


class TestReportCreate:

    def test_report_requires_auth(self, client):
        assert _post_report(client, {}, {"type": "biological_summary"}).status_code == 401

    def test_sync_report_returns_200(self, client, auth_headers_a):
        resp = _post_report(client, auth_headers_a, {
            "type":   "biological_summary",
            "format": "json",
            "async":  False,
            "parameters": {},
        })
        assert resp.status_code in (200, 422)  # 422 if type not registered
        if resp.status_code == 200:
            data = resp.get_json()
            assert "report_type" in data or "data" in data or "rows" in data

    def test_async_report_returns_202(self, client, auth_headers_a):
        resp = _post_report(client, auth_headers_a, {
            "type":   "biological_summary",
            "format": "csv",
            "async":  True,
            "parameters": {},
        })
        # 202 if Celery configured, 503 if not
        assert resp.status_code in (202, 503)
        if resp.status_code == 202:
            assert "job_id" in resp.get_json()

    def test_unknown_report_type_fails(self, client, auth_headers_a):
        resp = _post_report(client, auth_headers_a, {
            "type":   "nonexistent_report_xyz",
            "format": "json",
            "async":  False,
        })
        assert resp.status_code in (404, 422)

    def test_invalid_format_fails(self, client, auth_headers_a):
        resp = _post_report(client, auth_headers_a, {
            "type":   "biological_summary",
            "format": "exe",  # not allowed
            "async":  False,
        })
        assert resp.status_code == 422

    def test_read_only_cannot_create_report(self, client, auth_headers_readonly):
        resp = _post_report(client, auth_headers_readonly, {
            "type": "biological_summary", "format": "json", "async": False,
        })
        assert resp.status_code == 403

    def test_date_range_parameters_accepted(self, client, auth_headers_a):
        resp = _post_report(client, auth_headers_a, {
            "type":   "biological_summary",
            "format": "json",
            "async":  False,
            "parameters": {
                "start_date": "2024-01-01",
                "end_date":   "2024-12-31",
            },
        })
        assert resp.status_code in (200, 422)

    def test_company_id_auto_injected(self, client, auth_headers_a, auth_headers_b):
        """Reports must never leak cross-tenant data regardless of parameters."""
        for headers in (auth_headers_a, auth_headers_b):
            resp = _post_report(client, headers, {
                "type": "biological_summary", "format": "json", "async": False,
            })
            # Both should return 200 (or same status) — not leak each other's data
            assert resp.status_code in (200, 422, 503)


class TestJobStatus:

    def test_job_status_requires_auth(self, client):
        assert client.get("/api/v1/reports/fake-job-id/status").status_code == 401

    def test_nonexistent_job_returns_404(self, client, auth_headers_a):
        resp = client.get("/api/v1/reports/00000000-0000-0000-0000-000000000000/status",
                          headers=auth_headers_a)
        assert resp.status_code in (404, 422)

    def test_job_status_structure(self, client, auth_headers_a):
        """If Celery is configured, a queued job should have trackable status."""
        create_resp = _post_report(client, auth_headers_a, {
            "type": "biological_summary", "format": "json", "async": True,
        })
        if create_resp.status_code == 202:
            job_id = create_resp.get_json()["job_id"]
            status_resp = client.get(f"/api/v1/reports/{job_id}/status",
                                     headers=auth_headers_a)
            assert status_resp.status_code == 200
            data = status_resp.get_json()
            assert "status" in data
            assert data["status"] in ("pending", "running", "completed", "failed")


class TestReportPermissions:

    REPORT_TYPES = ["biological_summary", "procurement_summary", "trial_balance"]

    def test_all_report_types_require_report_view_permission(self, client,
                                                               auth_headers_readonly):
        """READ_ONLY role — check permission is enforced on all report types."""
        for report_type in self.REPORT_TYPES:
            resp = _post_report(client, auth_headers_readonly, {
                "type": report_type, "format": "json", "async": False,
            })
            assert resp.status_code == 403, \
                f"Expected 403 for READ_ONLY on {report_type}, got {resp.status_code}"
