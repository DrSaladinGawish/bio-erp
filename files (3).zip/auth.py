"""
app/auth.py
===========
Authentication & authorisation for the unified Bio-ERP platform.

Security model
--------------
* JWT stored in HTTP-only, Secure, SameSite=Strict cookies — NOT localStorage.
  (The existing navigation.js localStorage approach is an XSS critical; this
  module replaces it entirely.)
* Access token: 15-minute TTL.  Short window limits replay window.
* Refresh token: 7-day TTL, stored in a separate HTTP-only cookie.
  Refresh tokens are single-use (rotated on every refresh) and stored in the
  database so they can be revoked server-side.
* CSRF: Double-submit cookie pattern.  A csrf_token claim lives in the JWT and
  is mirrored as a readable (non-HttpOnly) cookie.  Every state-changing
  endpoint validates X-CSRF-Token header == cookie value.
* RBAC: Five roles in strict hierarchy.  Permission checks use the @require_*
  decorators; company_id is injected from the token, never from the request body.
* Audit: Every login, logout, failed attempt, and token refresh is written to
  the auth_audit_log table with correlation_id, IP, and user-agent.
* Rate limiting: Configured via Flask-Limiter (applied in the blueprint
  registration in routes/auth.py); the constants are defined here for DRY use.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import secrets
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from functools import wraps
from typing import Callable, Optional

import bcrypt
import jwt
from flask import Request, current_app, g, jsonify, make_response, request
from jwt.exceptions import (
    ExpiredSignatureError,
    InvalidSignatureError,
    InvalidTokenError,
)
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Rate-limit strings (consumed by Flask-Limiter in routes/auth.py)
# ---------------------------------------------------------------------------
RATE_LOGIN          = "5 per minute"
RATE_REFRESH        = "10 per minute"
RATE_PASSWORD_RESET = "3 per hour"

# ---------------------------------------------------------------------------
# Cookie names (single source of truth)
# ---------------------------------------------------------------------------
COOKIE_ACCESS   = "erp_access"
COOKIE_REFRESH  = "erp_refresh"
COOKIE_CSRF     = "erp_csrf"   # readable (not HttpOnly) — used by JS headers

# ---------------------------------------------------------------------------
# Token TTLs
# ---------------------------------------------------------------------------
ACCESS_TTL_SECONDS  = 15 * 60          # 15 minutes
REFRESH_TTL_SECONDS = 7  * 24 * 3600   # 7 days

# ---------------------------------------------------------------------------
# RBAC role hierarchy
# ---------------------------------------------------------------------------

class Role(str, Enum):
    """
    Roles in ascending privilege order.
    Use Role.rank() to compare: higher rank = more privilege.
    """
    READ_ONLY      = "read_only"
    USER           = "user"
    MANAGER        = "manager"
    COMPANY_ADMIN  = "company_admin"
    SUPER_ADMIN    = "super_admin"   # cross-tenant; only Anthropic ops

    # Permissions granted to each role (additive from lowest)
    _PERMISSIONS: dict[str, frozenset[str]] = {}   # populated below

    @classmethod
    def rank(cls, role: "Role") -> int:
        order = [cls.READ_ONLY, cls.USER, cls.MANAGER,
                 cls.COMPANY_ADMIN, cls.SUPER_ADMIN]
        return order.index(role)

    @classmethod
    def from_string(cls, value: str) -> "Role":
        try:
            return cls(value)
        except ValueError:
            raise ValueError(f"Unknown role: {value!r}")


# Permission strings — granular capabilities checked in decorators
class Permission(str, Enum):
    # Entity CRUD
    ENTITY_READ    = "entity:read"
    ENTITY_CREATE  = "entity:create"
    ENTITY_UPDATE  = "entity:update"
    ENTITY_DELETE  = "entity:delete"

    # Relation management
    RELATION_READ   = "relation:read"
    RELATION_WRITE  = "relation:write"
    RELATION_DELETE = "relation:delete"

    # Financial
    BUDGET_VIEW    = "budget:view"
    BUDGET_COMMIT  = "budget:commit"
    BUDGET_APPROVE = "budget:approve"

    # Reports
    REPORT_VIEW    = "report:view"
    REPORT_EXPORT  = "report:export"
    REPORT_SCHEDULE = "report:schedule"

    # Admin
    USER_MANAGE    = "user:manage"
    AUDIT_VIEW     = "audit:view"
    TENANT_MANAGE  = "tenant:manage"   # SUPER_ADMIN only

    # System
    BACKUP_TRIGGER = "backup:trigger"
    BACKUP_RESTORE = "backup:restore"


# Role → permission mapping
_ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.READ_ONLY: frozenset({
        Permission.ENTITY_READ,
        Permission.RELATION_READ,
        Permission.BUDGET_VIEW,
        Permission.REPORT_VIEW,
    }),
    Role.USER: frozenset({
        Permission.ENTITY_READ,
        Permission.ENTITY_CREATE,
        Permission.ENTITY_UPDATE,
        Permission.RELATION_READ,
        Permission.RELATION_WRITE,
        Permission.BUDGET_VIEW,
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
    }),
    Role.MANAGER: frozenset({
        Permission.ENTITY_READ,
        Permission.ENTITY_CREATE,
        Permission.ENTITY_UPDATE,
        Permission.ENTITY_DELETE,
        Permission.RELATION_READ,
        Permission.RELATION_WRITE,
        Permission.RELATION_DELETE,
        Permission.BUDGET_VIEW,
        Permission.BUDGET_COMMIT,
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
        Permission.REPORT_SCHEDULE,
        Permission.AUDIT_VIEW,
    }),
    Role.COMPANY_ADMIN: frozenset({
        Permission.ENTITY_READ,
        Permission.ENTITY_CREATE,
        Permission.ENTITY_UPDATE,
        Permission.ENTITY_DELETE,
        Permission.RELATION_READ,
        Permission.RELATION_WRITE,
        Permission.RELATION_DELETE,
        Permission.BUDGET_VIEW,
        Permission.BUDGET_COMMIT,
        Permission.BUDGET_APPROVE,
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
        Permission.REPORT_SCHEDULE,
        Permission.USER_MANAGE,
        Permission.AUDIT_VIEW,
        Permission.BACKUP_TRIGGER,
        Permission.BACKUP_RESTORE,
    }),
    Role.SUPER_ADMIN: frozenset(Permission),   # all permissions
}


def permissions_for(role: Role) -> frozenset[Permission]:
    """Return the complete permission set for a role."""
    return _ROLE_PERMISSIONS.get(role, frozenset())


def role_has_permission(role: Role, permission: Permission) -> bool:
    return permission in permissions_for(role)


# ---------------------------------------------------------------------------
# Token payload dataclass
# ---------------------------------------------------------------------------

@dataclass
class TokenData:
    """
    Validated, decoded JWT payload attached to g.token_data by
    @require_auth.  Downstream code reads from this — never from
    request headers or cookies directly.
    """
    user_id:        int
    company_id:     int          # -1 for SUPER_ADMIN cross-tenant calls
    role:           Role
    jti:            str          # JWT ID — used for refresh-token rotation
    csrf_token:     str
    permissions:    frozenset[Permission] = field(default_factory=frozenset)

    def has_permission(self, perm: Permission) -> bool:
        return perm in self.permissions

    def can_access_company(self, company_id: int) -> bool:
        """SUPER_ADMIN can access any tenant; others only their own."""
        if self.role == Role.SUPER_ADMIN:
            return True
        return self.company_id == company_id


# ---------------------------------------------------------------------------
# Password utilities (bcrypt)
# ---------------------------------------------------------------------------

def hash_password(plain: str) -> str:
    """
    Hash a plaintext password with bcrypt (cost=12).
    Returns a utf-8 string suitable for storage.
    """
    if len(plain) > 72:
        # bcrypt silently truncates at 72 bytes; reject long passwords
        # to avoid false "password match" on truncated inputs.
        raise ValueError("Password must not exceed 72 characters")
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(plain.encode(), salt).decode()


def verify_password(plain: str, hashed: str) -> bool:
    """
    Constant-time password comparison via bcrypt.
    Returns False (not an exception) on mismatch.
    """
    try:
        return bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------

def _secret() -> str:
    """Read JWT secret from app config — never hardcode."""
    secret = current_app.config.get("JWT_SECRET_KEY")
    if not secret:
        raise RuntimeError("JWT_SECRET_KEY is not set in app configuration")
    return secret


def _algorithm() -> str:
    return current_app.config.get("JWT_ALGORITHM", "HS256")


def create_access_token(
    user_id: int,
    company_id: int,
    role: Role,
    csrf_token: str,
) -> str:
    """
    Create a signed JWT access token.

    Claims:
        sub  — user_id (string per JWT spec)
        cid  — company_id
        rol  — role string
        csr  — CSRF token (validated on every state-changing request)
        jti  — unique token ID (used for refresh-token rotation lookup)
        iat  — issued-at (UTC)
        exp  — expiry (UTC, ACCESS_TTL_SECONDS from now)
    """
    now = datetime.now(UTC)
    payload = {
        "sub": str(user_id),
        "cid": company_id,
        "rol": role.value,
        "csr": csrf_token,
        "jti": str(uuid.uuid4()),
        "iat": now,
        "exp": now + timedelta(seconds=ACCESS_TTL_SECONDS),
    }
    return jwt.encode(payload, _secret(), algorithm=_algorithm())


def create_refresh_token(user_id: int, family_id: str) -> tuple[str, str]:
    """
    Create a refresh token.

    family_id groups all tokens in one login session so that if a
    refresh token is stolen and used, we can revoke the entire family
    (detect reuse attack).

    Returns (encoded_token, jti).
    """
    now = datetime.now(UTC)
    jti = str(uuid.uuid4())
    payload = {
        "sub": str(user_id),
        "fam": family_id,
        "jti": jti,
        "iat": now,
        "exp": now + timedelta(seconds=REFRESH_TTL_SECONDS),
        "typ": "refresh",
    }
    return jwt.encode(payload, _secret(), algorithm=_algorithm()), jti


def decode_token(token: str) -> dict:
    """
    Decode and verify a JWT.  Raises jwt.exceptions.* on failure.
    Callers must handle ExpiredSignatureError and InvalidTokenError.
    """
    return jwt.decode(token, _secret(), algorithms=[_algorithm()])


def _extract_token_from_cookie(cookie_name: str) -> Optional[str]:
    """Read a raw token string from a named cookie."""
    return request.cookies.get(cookie_name)


# ---------------------------------------------------------------------------
# Cookie builders
# ---------------------------------------------------------------------------

def _cookie_kwargs(secure: bool = True) -> dict:
    """Common secure cookie settings."""
    return {
        "httponly": True,
        "secure":   secure,          # False only in test/dev (HTTP)
        "samesite": "Strict",
        "path":     "/",
    }


def set_auth_cookies(
    response,
    user_id: int,
    company_id: int,
    role: Role,
    db: Session,
) -> str:
    """
    Mint access + refresh tokens and write all three cookies onto
    `response`.  Returns the csrf_token so callers can include it in
    JSON responses for initial page loads.

    Cookies set:
        erp_access   HttpOnly, Secure, SameSite=Strict  (15 min)
        erp_refresh  HttpOnly, Secure, SameSite=Strict  (7 days)
        erp_csrf     Readable by JS (not HttpOnly)       (15 min)
    """
    csrf_token = secrets.token_urlsafe(32)
    access_jwt = create_access_token(user_id, company_id, role, csrf_token)

    family_id = str(uuid.uuid4())
    refresh_jwt, refresh_jti = create_refresh_token(user_id, family_id)

    # Persist refresh token in DB for server-side revocation
    _store_refresh_token(db, user_id, refresh_jti, family_id)

    secure = current_app.config.get("SESSION_COOKIE_SECURE", True)
    kw     = _cookie_kwargs(secure)

    response.set_cookie(
        COOKIE_ACCESS,
        access_jwt,
        max_age=ACCESS_TTL_SECONDS,
        **kw,
    )
    response.set_cookie(
        COOKIE_REFRESH,
        refresh_jwt,
        max_age=REFRESH_TTL_SECONDS,
        **kw,
    )
    # CSRF cookie is intentionally NOT httponly — JS must read and
    # send it as X-CSRF-Token on every POST/PUT/PATCH/DELETE.
    response.set_cookie(
        COOKIE_CSRF,
        csrf_token,
        max_age=ACCESS_TTL_SECONDS,
        httponly=False,   # deliberate
        secure=secure,
        samesite="Strict",
        path="/",
    )
    return csrf_token


def clear_auth_cookies(response) -> None:
    """Expire all three auth cookies (used on logout)."""
    for name in (COOKIE_ACCESS, COOKIE_REFRESH, COOKIE_CSRF):
        response.set_cookie(
            name,
            "",
            max_age=0,
            httponly=True,
            secure=current_app.config.get("SESSION_COOKIE_SECURE", True),
            samesite="Strict",
            path="/",
        )


# ---------------------------------------------------------------------------
# Refresh-token DB persistence
# Requires Clarification: exact ORM model name for refresh tokens.
# Using a forward reference to RefreshToken; replace with your actual import.
# ---------------------------------------------------------------------------

def _store_refresh_token(
    db: Session,
    user_id: int,
    jti: str,
    family_id: str,
) -> None:
    """Persist a new refresh token record."""
    from app.models import RefreshToken  # imported here to avoid circular imports

    token_record = RefreshToken(
        jti=jti,
        user_id=user_id,
        family_id=family_id,
        expires_at=datetime.now(UTC) + timedelta(seconds=REFRESH_TTL_SECONDS),
        used=False,
    )
    db.add(token_record)
    db.commit()


def _revoke_token_family(db: Session, family_id: str) -> None:
    """
    Revoke all refresh tokens in a family.
    Called when a reuse attack is detected (token replayed after use).
    """
    from app.models import RefreshToken

    db.query(RefreshToken).filter(
        RefreshToken.family_id == family_id,
        RefreshToken.deleted_at.is_(None),
    ).update({"revoked": True, "revoked_at": datetime.now(UTC)})
    db.commit()
    logger.warning("Refresh token family revoked (reuse attack detected)",
                   extra={"family_id": family_id})


# ---------------------------------------------------------------------------
# CSRF validation
# ---------------------------------------------------------------------------

_CSRF_SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})


def _validate_csrf() -> Optional[tuple[dict, int]]:
    """
    Double-submit cookie CSRF check for state-changing requests.

    The JWT contains a csrf_token claim.  The client must read the
    erp_csrf cookie (which is readable by JS) and send it as the
    X-CSRF-Token header.  We compare header value against the claim
    inside the signed JWT — an attacker cannot forge the JWT claim
    even if they can read the cookie from another domain (they can't
    due to SameSite=Strict, but defence-in-depth).

    Returns None on success, or (error_dict, status_code) on failure.
    """
    if request.method in _CSRF_SAFE_METHODS:
        return None

    token_data: Optional[TokenData] = g.get("token_data")
    if token_data is None:
        return {"error": "Not authenticated"}, 401

    header_csrf = request.headers.get("X-CSRF-Token", "")
    cookie_csrf = request.cookies.get(COOKIE_CSRF, "")

    # Compare against both the header and the JWT claim
    if not (
        hmac.compare_digest(header_csrf, token_data.csrf_token)
        and hmac.compare_digest(cookie_csrf, token_data.csrf_token)
    ):
        _log_auth_event("csrf_failure", user_id=token_data.user_id)
        return {"error": "CSRF token mismatch"}, 403

    return None


# ---------------------------------------------------------------------------
# Auth audit logging
# ---------------------------------------------------------------------------

def _log_auth_event(
    event: str,
    user_id: Optional[int] = None,
    company_id: Optional[int] = None,
    extra: Optional[dict] = None,
) -> None:
    """
    Emit a structured auth audit log entry.
    The observability module picks this up and writes to auth_audit_log.
    """
    correlation_id = g.get("correlation_id", str(uuid.uuid4()))
    record = {
        "event":          event,
        "user_id":        user_id,
        "company_id":     company_id,
        "ip":             request.remote_addr,
        "user_agent":     request.user_agent.string[:200] if request.user_agent else "",
        "correlation_id": correlation_id,
        "timestamp":      datetime.now(UTC).isoformat(),
        **(extra or {}),
    }
    logger.info("auth_event", extra=record)


# ---------------------------------------------------------------------------
# Core auth decorator
# ---------------------------------------------------------------------------

def require_auth(f: Callable) -> Callable:
    """
    Decorator: validates the access token cookie, populates g.token_data,
    and validates CSRF for state-changing methods.

    Usage::

        @app.route("/api/v1/cells", methods=["POST"])
        @require_auth
        def create_cell():
            td: TokenData = g.token_data
            # td.company_id is safe to use as a query filter
    """
    @wraps(f)
    def wrapper(*args, **kwargs):
        raw_token = _extract_token_from_cookie(COOKIE_ACCESS)
        if not raw_token:
            return jsonify({"error": "Authentication required"}), 401

        try:
            payload = decode_token(raw_token)
        except ExpiredSignatureError:
            return jsonify({"error": "Access token expired", "code": "TOKEN_EXPIRED"}), 401
        except (InvalidSignatureError, InvalidTokenError) as exc:
            logger.warning("Invalid token presented: %s", exc,
                           extra={"ip": request.remote_addr})
            return jsonify({"error": "Invalid token"}), 401

        try:
            role = Role.from_string(payload["rol"])
        except ValueError:
            return jsonify({"error": "Invalid role in token"}), 401

        g.token_data = TokenData(
            user_id=int(payload["sub"]),
            company_id=int(payload["cid"]),
            role=role,
            jti=payload["jti"],
            csrf_token=payload["csr"],
            permissions=permissions_for(role),
        )

        csrf_error = _validate_csrf()
        if csrf_error:
            return jsonify({"error": csrf_error[0]}), csrf_error[1]

        return f(*args, **kwargs)

    return wrapper


# ---------------------------------------------------------------------------
# RBAC decorators — compose on top of @require_auth
# ---------------------------------------------------------------------------

def require_role(minimum_role: Role) -> Callable:
    """
    Decorator factory: requires the caller to have at least `minimum_role`.

    Usage::

        @app.route("/api/v1/budgets/approve", methods=["POST"])
        @require_auth
        @require_role(Role.MANAGER)
        def approve_budget():
            ...
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def wrapper(*args, **kwargs):
            td: Optional[TokenData] = g.get("token_data")
            if td is None:
                return jsonify({"error": "Not authenticated"}), 401
            if Role.rank(td.role) < Role.rank(minimum_role):
                _log_auth_event(
                    "insufficient_role",
                    user_id=td.user_id,
                    extra={"required": minimum_role.value, "actual": td.role.value},
                )
                return jsonify({
                    "error": "Insufficient role",
                    "required": minimum_role.value,
                    "your_role": td.role.value,
                }), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator


def require_permission(permission: Permission) -> Callable:
    """
    Decorator factory: requires a specific permission.
    More granular than require_role when actions don't map cleanly to hierarchy.

    Usage::

        @app.route("/api/v1/backups/restore", methods=["POST"])
        @require_auth
        @require_permission(Permission.BACKUP_RESTORE)
        def restore_backup():
            ...
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def wrapper(*args, **kwargs):
            td: Optional[TokenData] = g.get("token_data")
            if td is None:
                return jsonify({"error": "Not authenticated"}), 401
            if not td.has_permission(permission):
                _log_auth_event(
                    "permission_denied",
                    user_id=td.user_id,
                    extra={"required": permission.value},
                )
                return jsonify({
                    "error": "Permission denied",
                    "required_permission": permission.value,
                }), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator


def require_same_company(company_id_param: str = "company_id") -> Callable:
    """
    Decorator factory: asserts the caller's company_id matches the
    `company_id` present in the request (URL param, JSON body, or
    route kwarg).  SUPER_ADMIN bypasses this check.

    Usage::

        @app.route("/api/v1/companies/<int:company_id>/cells", methods=["GET"])
        @require_auth
        @require_same_company("company_id")
        def list_cells(company_id: int):
            ...
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def wrapper(*args, **kwargs):
            td: Optional[TokenData] = g.get("token_data")
            if td is None:
                return jsonify({"error": "Not authenticated"}), 401

            # Try route kwargs first, then query params, then JSON body
            target_company = (
                kwargs.get(company_id_param)
                or request.args.get(company_id_param, type=int)
                or (request.get_json(silent=True) or {}).get(company_id_param)
            )

            if target_company is not None and not td.can_access_company(int(target_company)):
                _log_auth_event(
                    "cross_tenant_attempt",
                    user_id=td.user_id,
                    company_id=td.company_id,
                    extra={"requested_company": target_company},
                )
                return jsonify({"error": "Access to this tenant is not permitted"}), 403

            return f(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Refresh token rotation endpoint logic
# (called by the route in routes/auth.py — kept here for testability)
# ---------------------------------------------------------------------------

def rotate_refresh_token(db: Session) -> tuple[dict, int]:
    """
    Validate the incoming refresh token cookie, issue a new access +
    refresh token pair, and return a response dict with the new csrf_token.

    Implements refresh-token rotation with reuse detection:
    - On valid use: old token marked used, new token minted.
    - On reuse (token already used): entire family revoked → force re-login.

    Returns (response_body_dict, http_status_code).
    Caller must call set_auth_cookies() on the Flask response object.
    """
    from app.models import RefreshToken, User  # avoid circular imports

    raw = _extract_token_from_cookie(COOKIE_REFRESH)
    if not raw:
        return {"error": "No refresh token"}, 401

    try:
        payload = decode_token(raw)
    except ExpiredSignatureError:
        return {"error": "Refresh token expired. Please log in again.", "code": "REFRESH_EXPIRED"}, 401
    except InvalidTokenError:
        return {"error": "Invalid refresh token"}, 401

    if payload.get("typ") != "refresh":
        return {"error": "Wrong token type"}, 401

    jti       = payload["jti"]
    family_id = payload["fam"]
    user_id   = int(payload["sub"])

    token_record = (
        db.query(RefreshToken)
        .filter(
            RefreshToken.jti == jti,
            RefreshToken.deleted_at.is_(None),
        )
        .first()
    )

    if token_record is None:
        # Token not found — possible reuse attack; revoke entire family
        _revoke_token_family(db, family_id)
        _log_auth_event("refresh_reuse_attack", user_id=user_id,
                        extra={"family_id": family_id})
        return {"error": "Refresh token reuse detected. All sessions revoked."}, 401

    if token_record.used or token_record.revoked:
        _revoke_token_family(db, family_id)
        _log_auth_event("refresh_reuse_attack", user_id=user_id,
                        extra={"family_id": family_id, "already_used": True})
        return {"error": "Refresh token already used. All sessions revoked."}, 401

    if token_record.expires_at < datetime.now(UTC):
        return {"error": "Refresh token expired"}, 401

    # Mark old token as used
    token_record.used    = True
    token_record.used_at = datetime.now(UTC)
    db.commit()

    # Load user for role — verify user still active
    user = (
        db.query(User)
        .filter(User.id == user_id, User.deleted_at.is_(None), User.is_active == True)
        .first()
    )
    if not user:
        return {"error": "User account is inactive"}, 401

    _log_auth_event("token_refresh", user_id=user_id, company_id=user.company_id)

    return {
        "status":     "ok",
        "user_id":    user_id,
        "company_id": user.company_id,
        "role":       user.role,
    }, 200


# ---------------------------------------------------------------------------
# Login logic (called by routes/auth.py blueprint)
# ---------------------------------------------------------------------------

def authenticate_user(
    email: str,
    password: str,
    db: Session,
) -> tuple[Optional["User"], Optional[str]]:  # type: ignore[name-defined]
    """
    Verify credentials.  Returns (user, None) on success,
    (None, error_message) on failure.

    Timing-safe: always runs bcrypt even if user not found, to prevent
    user-enumeration via response timing.
    """
    from app.models import User

    # Normalise email
    email = email.strip().lower()

    user = (
        db.query(User)
        .filter(User.email == email, User.deleted_at.is_(None))
        .first()
    )

    # Always run bcrypt — prevents timing side-channel user enumeration
    candidate_hash = user.password_hash if user else "$2b$12$invalidhashpadding0000000000000000000000000000000000000"
    password_ok    = verify_password(password, candidate_hash)

    if not user or not password_ok:
        _log_auth_event("login_failure", extra={"email_hint": _mask_email(email)})
        return None, "Invalid email or password"

    if not user.is_active:
        _log_auth_event("login_inactive", user_id=user.id, company_id=user.company_id)
        return None, "Account is inactive. Contact your administrator."

    # Update last_login (non-critical; don't fail the login if this errors)
    try:
        user.last_login = datetime.now(UTC)
        db.commit()
    except Exception as exc:
        logger.warning("Could not update last_login: %s", exc)
        db.rollback()

    _log_auth_event("login_success", user_id=user.id, company_id=user.company_id)
    return user, None


def _mask_email(email: str) -> str:
    """Mask email for safe logging: user@domain.com → u***@domain.com"""
    parts = email.split("@", 1)
    if len(parts) != 2:
        return "***"
    local, domain = parts
    return f"{local[:1]}***@{domain}" if local else f"***@{domain}"


# ---------------------------------------------------------------------------
# Correlation ID middleware (attach before_request)
# ---------------------------------------------------------------------------

def attach_correlation_id() -> None:
    """
    Flask before_request hook.
    Reads X-Correlation-ID from incoming request or generates a new UUID.
    Stored in g.correlation_id; included in all log records.
    """
    g.correlation_id = (
        request.headers.get("X-Correlation-ID")
        or str(uuid.uuid4())
    )


def add_correlation_header(response):
    """Flask after_request hook — echo correlation_id back in response."""
    response.headers["X-Correlation-ID"] = g.get("correlation_id", "")
    return response


# ---------------------------------------------------------------------------
# Convenience: get current user from g (for use inside route handlers)
# ---------------------------------------------------------------------------

def current_user() -> TokenData:
    """
    Return the authenticated TokenData from g.
    Raises RuntimeError if called outside of @require_auth context.
    """
    td = g.get("token_data")
    if td is None:
        raise RuntimeError(
            "current_user() called outside an @require_auth-protected route. "
            "Apply @require_auth before calling this."
        )
    return td


def current_company_id() -> int:
    """Shorthand for current_user().company_id."""
    return current_user().company_id
