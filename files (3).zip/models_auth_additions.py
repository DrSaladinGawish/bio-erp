"""
app/models_auth_additions.py
============================
SQLAlchemy models that app/auth.py depends on.

ACTION REQUIRED: Merge these into your existing app/models.py alongside
the 43+ entity models you already wrote.  They are kept separate here
so you can copy-paste without touching the rest of models.py.

Tables added:
    users           — application users with role + tenant
    refresh_tokens  — server-side refresh token store (revocation support)
    auth_audit_log  — immutable login/logout/failure audit trail
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship

# Import the shared Base, AuditMixin, SoftDeleteMixin from your models.py
# Adjust the import path if your Base lives elsewhere.
from app.models import AuditMixin, Base, SoftDeleteMixin


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------

class User(SoftDeleteMixin, Base):
    """
    Application user.

    * company_id = -1 is reserved for SUPER_ADMIN users who can access
      all tenants.  All other users must have a valid company_id.
    * role is stored as a plain string matching app.auth.Role enum values.
    * password_hash is bcrypt(cost=12); plaintext passwords never stored.
    """
    __tablename__ = "users"
    __table_args__ = (
        UniqueConstraint("email", name="uq_users_email"),
        Index("ix_users_company_active",
              "company_id", "deleted_at"),         # common query pattern
        Index("ix_users_email_lower", "email"),    # login lookup
    )

    id            = Column(BigInteger, primary_key=True, autoincrement=True)
    company_id    = Column(BigInteger, nullable=False, index=True)
    email         = Column(String(254), nullable=False)
    display_name  = Column(String(120), nullable=False)
    password_hash = Column(String(128), nullable=False)   # bcrypt output
    role          = Column(String(32),  nullable=False, default="user")
    is_active     = Column(Boolean,     nullable=False, default=True)
    last_login    = Column(DateTime(timezone=True), nullable=True)

    refresh_tokens = relationship(
        "RefreshToken",
        back_populates="user",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} email={self.email!r} role={self.role!r}>"


# ---------------------------------------------------------------------------
# RefreshToken
# ---------------------------------------------------------------------------

class RefreshToken(Base):
    """
    Server-side refresh token store.

    Why store refresh tokens?
        * Enables server-side revocation (logout, suspicious activity).
        * Supports refresh-token rotation with reuse detection (theft detection).
        * family_id groups all tokens from one login session; compromised
          family → revoke all, forcing re-login.

    Rows are never hard-deleted; set revoked=True or used=True instead.
    Expired rows are pruned by a weekly Celery task (tasks/cleanup.py).
    """
    __tablename__ = "refresh_tokens"
    __table_args__ = (
        Index("ix_rt_jti",       "jti",       unique=True),
        Index("ix_rt_family",    "family_id"),
        Index("ix_rt_user_live", "user_id",   "used", "revoked"),
    )

    id         = Column(BigInteger, primary_key=True, autoincrement=True)
    jti        = Column(String(36),  nullable=False, unique=True)   # UUID
    user_id    = Column(BigInteger,
                        ForeignKey("users.id", ondelete="CASCADE"),
                        nullable=False)
    family_id  = Column(String(36),  nullable=False)                # login session group
    expires_at = Column(DateTime(timezone=True), nullable=False)
    used       = Column(Boolean, nullable=False, default=False)
    used_at    = Column(DateTime(timezone=True), nullable=True)
    revoked    = Column(Boolean, nullable=False, default=False)
    revoked_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True),
                        default=lambda: datetime.now(UTC),
                        nullable=False)
    deleted_at = Column(DateTime(timezone=True), nullable=True)     # soft-delete compat

    user = relationship("User", back_populates="refresh_tokens")

    def __repr__(self) -> str:
        return (
            f"<RefreshToken jti={self.jti[:8]}… "
            f"user={self.user_id} used={self.used} revoked={self.revoked}>"
        )


# ---------------------------------------------------------------------------
# AuthAuditLog
# ---------------------------------------------------------------------------

class AuthAuditLog(Base):
    """
    Immutable authentication audit trail.

    Records are INSERT-only; no UPDATE or DELETE is ever issued on this
    table.  A Celery task archives rows older than 12 months to cold storage.

    Hash chain (tamper detection)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Each row's chain_hash is SHA-256(prev_chain_hash || row_data).
    The integrity check in observability/health.py walks the chain and
    alerts if any hash mismatches — matching the audit chain pattern in
    bio-erp-local's in-memory implementation.
    """
    __tablename__ = "auth_audit_log"
    __table_args__ = (
        Index("ix_aal_user_ts",   "user_id",   "timestamp"),
        Index("ix_aal_company_ts","company_id", "timestamp"),
        Index("ix_aal_event",     "event"),
    )

    id             = Column(BigInteger, primary_key=True, autoincrement=True)
    event          = Column(String(64),  nullable=False)
    user_id        = Column(BigInteger,  nullable=True)   # null for pre-auth failures
    company_id     = Column(BigInteger,  nullable=True)
    ip_address     = Column(String(45),  nullable=True)   # IPv4 or IPv6
    user_agent     = Column(String(200), nullable=True)
    correlation_id = Column(String(36),  nullable=True)
    extra_json     = Column(Text,        nullable=True)   # JSON blob for flexible data
    chain_hash     = Column(String(64),  nullable=True)   # SHA-256 tamper-evidence
    timestamp      = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
        index=True,
    )

    def __repr__(self) -> str:
        return (
            f"<AuthAuditLog id={self.id} event={self.event!r} "
            f"user={self.user_id} ts={self.timestamp}>"
        )
