"""
tests/test_auth.py
==================
Tests for app/auth.py and app/routes/auth_bp.py

Coverage targets
----------------
* Password hashing (hash + verify, length limits, timing safety)
* Token creation (access, refresh, claims, expiry)
* Cookie settings (HttpOnly, Secure, SameSite, path)
* CSRF double-submit validation (pass, fail, missing)
* RBAC decorators (require_auth, require_role, require_permission, require_same_company)
* Refresh token rotation (valid use, reuse attack, family revocation)
* Login (success, wrong password, inactive user, timing attack mitigation)
* Logout (cookie clearance, DB revocation)
* Password strength (all rules, edge cases)
* Cross-tenant isolation (company_id gating)
* Rate limit constants (not their enforcement — that's Flask-Limiter's job)

Run with:
    pytest tests/test_auth.py -v --cov=app.auth --cov-report=term-missing
"""

from __future__ import annotations

import time
import uuid
from datetime import UTC, datetime, timedelta
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# We test the pure functions in auth.py without a running Flask app where
# possible, using app-context fixtures only where flask.g or current_app
# are required.
# ---------------------------------------------------------------------------


# ============================================================
# Fixtures
# ============================================================

@pytest.fixture
def app():
    """Minimal Flask app for tests that need application context."""
    from flask import Flask
    application = Flask(__name__)
    application.config.update({
        "TESTING":                  True,
        "JWT_SECRET_KEY":           "test-secret-key-not-for-production",
        "JWT_ALGORITHM":            "HS256",
        "SESSION_COOKIE_SECURE":    False,   # HTTP in tests
        "WTF_CSRF_ENABLED":         False,
    })
    return application


@pytest.fixture
def app_ctx(app):
    """Push an application context for tests that call current_app."""
    with app.app_context():
        yield app


@pytest.fixture
def req_ctx(app):
    """Push a request context with a POST JSON payload."""
    with app.test_request_context(
        "/api/v1/auth/login",
        method="POST",
        json={"email": "test@example.com", "password": "TestPass1!"},
    ):
        from flask import g
        g.correlation_id = str(uuid.uuid4())
        yield


@pytest.fixture
def mock_db():
    """SQLAlchemy session mock."""
    return MagicMock()


@pytest.fixture
def mock_user():
    """A mock User ORM object."""
    from app.auth import Role, hash_password

    user = MagicMock()
    user.id           = 42
    user.company_id   = 7
    user.email        = "user@example.com"
    user.display_name = "Test User"
    user.role         = Role.MANAGER.value
    user.is_active    = True
    user.last_login   = None
    user.password_hash = hash_password("TestPass1!")
    user.deleted_at   = None
    return user


# ============================================================
# Password hashing tests
# ============================================================

class TestPasswordHashing:

    def test_hash_is_not_plaintext(self):
        from app.auth import hash_password
        hashed = hash_password("TestPass1!")
        assert hashed != "TestPass1!"

    def test_bcrypt_prefix(self):
        from app.auth import hash_password
        hashed = hash_password("TestPass1!")
        assert hashed.startswith("$2b$")

    def test_verify_correct_password(self):
        from app.auth import hash_password, verify_password
        hashed = hash_password("TestPass1!")
        assert verify_password("TestPass1!", hashed) is True

    def test_verify_wrong_password(self):
        from app.auth import hash_password, verify_password
        hashed = hash_password("TestPass1!")
        assert verify_password("WrongPass!", hashed) is False

    def test_password_over_72_chars_raises(self):
        from app.auth import hash_password
        with pytest.raises(ValueError, match="72"):
            hash_password("A" * 73)

    def test_password_exactly_72_chars_ok(self):
        from app.auth import hash_password
        # Should not raise
        hashed = hash_password("A" * 72)
        assert hashed.startswith("$2b$")

    def test_verify_returns_false_on_invalid_hash(self):
        """verify_password must return False (not raise) on malformed hashes."""
        from app.auth import verify_password
        result = verify_password("any", "not-a-valid-hash")
        assert result is False

    def test_different_hashes_for_same_password(self):
        """bcrypt uses random salts; identical passwords produce different hashes."""
        from app.auth import hash_password
        h1 = hash_password("TestPass1!")
        h2 = hash_password("TestPass1!")
        assert h1 != h2

    def test_timing_safety_invalid_hash(self):
        """
        verify_password should take roughly the same time for an invalid hash
        as for a valid one — preventing timing-based user enumeration.
        We don't assert exact milliseconds (too flaky) but confirm no instant return.
        """
        from app.auth import verify_password
        start = time.monotonic()
        verify_password("some-password", "$2b$12$invalidhashpadding0000000000000000000000000000000000000")
        elapsed = time.monotonic() - start
        # bcrypt with cost=12 should take at least 100ms; instant return < 1ms is a bug
        # Relaxed to 10ms to avoid CI flakiness on slow machines
        assert elapsed > 0.01, "verify_password returned too fast — timing side-channel risk"


# ============================================================
# Token creation tests
# ============================================================

class TestTokenCreation:

    def test_access_token_is_string(self, app_ctx):
        from app.auth import Role, create_access_token
        token = create_access_token(1, 7, Role.USER, "csrf-abc")
        assert isinstance(token, str)
        assert token.count(".") == 2   # JWT header.payload.signature

    def test_access_token_claims(self, app_ctx):
        from app.auth import Role, create_access_token, decode_token
        token = create_access_token(42, 7, Role.MANAGER, "csrf-xyz")
        payload = decode_token(token)
        assert payload["sub"] == "42"
        assert payload["cid"] == 7
        assert payload["rol"] == "manager"
        assert payload["csr"] == "csrf-xyz"
        assert "jti" in payload
        assert "exp" in payload
        assert "iat" in payload

    def test_access_token_expiry(self, app_ctx):
        from app.auth import ACCESS_TTL_SECONDS, Role, create_access_token, decode_token
        token = create_access_token(1, 1, Role.USER, "c")
        payload = decode_token(token)
        ttl_actual = payload["exp"] - payload["iat"]
        assert abs(ttl_actual - ACCESS_TTL_SECONDS) <= 2   # within 2 seconds

    def test_refresh_token_claims(self, app_ctx):
        from app.auth import create_refresh_token, decode_token
        token, jti = create_refresh_token(99, "family-abc")
        payload = decode_token(token)
        assert payload["sub"]  == "99"
        assert payload["fam"]  == "family-abc"
        assert payload["typ"]  == "refresh"
        assert payload["jti"]  == jti

    def test_refresh_token_returns_jti(self, app_ctx):
        from app.auth import create_refresh_token
        _, jti = create_refresh_token(1, "fam")
        assert len(jti) == 36   # UUID4 format


# ============================================================
# Cookie flag tests
# ============================================================

class TestCookieFlags:

    def test_access_cookie_is_httponly(self, app):
        """The access token cookie must never be readable by JavaScript."""
        client = app.test_client()
        with patch("app.routes.auth_bp.authenticate_user") as mock_auth, \
             patch("app.routes.auth_bp.get_db") as mock_get_db, \
             patch("app.auth._store_refresh_token"):
            from app.auth import Role
            mock_user = MagicMock(id=1, company_id=7, role="user")
            mock_auth.return_value = (mock_user, None)
            mock_get_db.return_value = MagicMock()

            with app.test_request_context():
                from flask import g
                g.correlation_id = "test"

            # Requires Clarification: full integration test requires routes
            # registered. Mark as pending until blueprint is wired into app.
            pytest.skip("Requires full app integration fixture — add to conftest.py")

    def test_csrf_cookie_is_not_httponly(self, app_ctx, req_ctx):
        """
        The CSRF cookie must NOT be HttpOnly so JS can read and send it
        as X-CSRF-Token header.  Verify the flag via the cookie kwargs.
        """
        from app.auth import COOKIE_CSRF, _cookie_kwargs
        # _cookie_kwargs returns httponly=True — the CSRF cookie overrides this
        kw = _cookie_kwargs(secure=False)
        assert kw["httponly"] is True   # base kwargs are httponly

        # The CSRF set_cookie call in set_auth_cookies explicitly sets httponly=False
        # We verify this by inspecting the source directly
        import inspect
        from app import auth
        source = inspect.getsource(auth.set_auth_cookies)
        assert "httponly=False" in source, \
            "CSRF cookie must have httponly=False in set_auth_cookies"
        assert "# deliberate" in source, \
            "CSRF cookie httponly=False must have an explanatory comment"


# ============================================================
# RBAC decorator tests
# ============================================================

class TestRBACDecorators:

    def _make_token_data(self, role_str: str, company_id: int = 7):
        from app.auth import Role, TokenData, permissions_for
        role = Role(role_str)
        return TokenData(
            user_id=1,
            company_id=company_id,
            role=role,
            jti="test-jti",
            csrf_token="test-csrf",
            permissions=permissions_for(role),
        )

    def test_role_rank_ordering(self):
        from app.auth import Role
        assert Role.rank(Role.READ_ONLY) < Role.rank(Role.USER)
        assert Role.rank(Role.USER)      < Role.rank(Role.MANAGER)
        assert Role.rank(Role.MANAGER)   < Role.rank(Role.COMPANY_ADMIN)
        assert Role.rank(Role.COMPANY_ADMIN) < Role.rank(Role.SUPER_ADMIN)

    def test_permissions_for_read_only(self):
        from app.auth import Permission, Role, permissions_for
        perms = permissions_for(Role.READ_ONLY)
        assert Permission.ENTITY_READ  in perms
        assert Permission.ENTITY_CREATE not in perms
        assert Permission.USER_MANAGE   not in perms

    def test_permissions_for_super_admin(self):
        from app.auth import Permission, Role, permissions_for
        perms = permissions_for(Role.SUPER_ADMIN)
        for perm in Permission:
            assert perm in perms, f"SUPER_ADMIN missing permission: {perm}"

    def test_manager_has_budget_commit(self):
        from app.auth import Permission, Role, permissions_for
        assert Permission.BUDGET_COMMIT in permissions_for(Role.MANAGER)

    def test_user_lacks_budget_approve(self):
        from app.auth import Permission, Role, permissions_for
        assert Permission.BUDGET_APPROVE not in permissions_for(Role.USER)

    def test_token_data_has_permission(self):
        from app.auth import Permission
        td = self._make_token_data("manager")
        assert td.has_permission(Permission.ENTITY_CREATE) is True
        assert td.has_permission(Permission.TENANT_MANAGE) is False

    def test_super_admin_can_access_any_company(self):
        from app.auth import Role, TokenData, permissions_for
        td = TokenData(
            user_id=1, company_id=-1, role=Role.SUPER_ADMIN,
            jti="j", csrf_token="c",
            permissions=permissions_for(Role.SUPER_ADMIN),
        )
        assert td.can_access_company(999) is True
        assert td.can_access_company(1)   is True

    def test_regular_user_cannot_access_other_company(self):
        td = self._make_token_data("user", company_id=7)
        assert td.can_access_company(7)  is True
        assert td.can_access_company(99) is False


# ============================================================
# CSRF validation tests
# ============================================================

class TestCSRFValidation:

    def test_csrf_skipped_on_get(self, app):
        """GET requests must not require CSRF token."""
        from app.auth import Role, TokenData, permissions_for

        with app.test_request_context("/any", method="GET"):
            from flask import g
            g.token_data = TokenData(
                user_id=1, company_id=7, role=Role.USER,
                jti="j", csrf_token="abc",
                permissions=permissions_for(Role.USER),
            )
            from app.auth import _validate_csrf
            result = _validate_csrf()
            assert result is None   # no error

    def test_csrf_fails_on_post_without_header(self, app):
        """POST without X-CSRF-Token header must be rejected."""
        from app.auth import Role, TokenData, permissions_for

        with app.test_request_context("/any", method="POST",
                                      headers={},
                                      environ_base={"HTTP_COOKIE": "erp_csrf=abc"}):
            from flask import g
            g.token_data = TokenData(
                user_id=1, company_id=7, role=Role.USER,
                jti="j", csrf_token="abc",
                permissions=permissions_for(Role.USER),
            )
            from app.auth import _validate_csrf
            result = _validate_csrf()
            assert result is not None
            _, status = result
            assert status == 403

    def test_csrf_passes_on_post_with_correct_header(self, app):
        """POST with matching X-CSRF-Token header and cookie must pass."""
        from app.auth import Role, TokenData, permissions_for

        csrf = "correct-csrf-value"
        with app.test_request_context(
            "/any", method="POST",
            headers={"X-CSRF-Token": csrf},
            environ_base={"HTTP_COOKIE": f"erp_csrf={csrf}"},
        ):
            from flask import g
            g.token_data = TokenData(
                user_id=1, company_id=7, role=Role.USER,
                jti="j", csrf_token=csrf,
                permissions=permissions_for(Role.USER),
            )
            from app.auth import _validate_csrf
            result = _validate_csrf()
            assert result is None   # no error

    def test_csrf_fails_on_header_cookie_mismatch(self, app):
        """Header and cookie values must both match the JWT claim."""
        from app.auth import Role, TokenData, permissions_for

        with app.test_request_context(
            "/any", method="POST",
            headers={"X-CSRF-Token": "attacker-token"},
            environ_base={"HTTP_COOKIE": "erp_csrf=real-token"},
        ):
            from flask import g
            g.token_data = TokenData(
                user_id=1, company_id=7, role=Role.USER,
                jti="j", csrf_token="real-token",
                permissions=permissions_for(Role.USER),
            )
            from app.auth import _validate_csrf
            result = _validate_csrf()
            assert result is not None
            _, status = result
            assert status == 403


# ============================================================
# Refresh token rotation tests
# ============================================================

class TestRefreshTokenRotation:

    def test_missing_refresh_cookie_returns_401(self, app):
        with app.test_request_context("/refresh", method="POST"):
            from app.auth import rotate_refresh_token
            result, status = rotate_refresh_token(MagicMock())
            assert status == 401
            assert "No refresh token" in result["error"]

    def test_expired_refresh_token_returns_401(self, app_ctx):
        import jwt as pyjwt
        from app.auth import REFRESH_TTL_SECONDS, rotate_refresh_token

        # Craft an already-expired token
        secret = app_ctx.config["JWT_SECRET_KEY"]
        past   = datetime.now(UTC) - timedelta(seconds=REFRESH_TTL_SECONDS + 1)
        expired_payload = {
            "sub": "1", "fam": "fam-abc", "jti": "jti-abc",
            "typ": "refresh",
            "iat": past,
            "exp": past + timedelta(seconds=1),   # expired
        }
        token = pyjwt.encode(expired_payload, secret, algorithm="HS256")

        with app_ctx.test_request_context(
            "/refresh", method="POST",
            environ_base={"HTTP_COOKIE": f"erp_refresh={token}"},
        ):
            result, status = rotate_refresh_token(MagicMock())
            assert status == 401
            assert "expired" in result["error"].lower()

    def test_reuse_attack_revokes_family(self, app_ctx):
        """If a refresh token's JTI is not in the DB, the whole family is revoked."""
        import jwt as pyjwt
        from app.auth import rotate_refresh_token

        secret  = app_ctx.config["JWT_SECRET_KEY"]
        payload = {
            "sub": "1", "fam": "fam-xyz", "jti": "jti-not-in-db",
            "typ": "refresh",
            "iat": datetime.now(UTC),
            "exp": datetime.now(UTC) + timedelta(days=7),
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        db = MagicMock()
        # Simulate RefreshToken not found in DB
        db.query.return_value.filter.return_value.first.return_value = None

        with app_ctx.test_request_context(
            "/refresh", method="POST",
            environ_base={"HTTP_COOKIE": f"erp_refresh={token}"},
        ):
            with patch("app.auth._revoke_token_family") as mock_revoke:
                from app import models as _m
                with patch.object(_m, "RefreshToken", MagicMock()):
                    result, status = rotate_refresh_token(db)

            assert status == 401
            assert "reuse" in result["error"].lower()


# ============================================================
# Authenticate user tests
# ============================================================

class TestAuthenticateUser:

    def test_success(self, app_ctx, mock_user, mock_db):
        mock_db.query.return_value.filter.return_value.first.return_value = mock_user

        with app_ctx.test_request_context("/login", method="POST"):
            from flask import g
            g.correlation_id = "test"
            from app.auth import authenticate_user
            user, err = authenticate_user("user@example.com", "TestPass1!", mock_db)

        assert err is None
        assert user is mock_user

    def test_wrong_password(self, app_ctx, mock_user, mock_db):
        mock_db.query.return_value.filter.return_value.first.return_value = mock_user

        with app_ctx.test_request_context("/login", method="POST"):
            from flask import g
            g.correlation_id = "test"
            from app.auth import authenticate_user
            user, err = authenticate_user("user@example.com", "WrongPass!", mock_db)

        assert user is None
        assert err is not None

    def test_nonexistent_user_still_runs_bcrypt(self, app_ctx, mock_db):
        """
        When user is not found, bcrypt must still run (timing attack mitigation).
        We verify it doesn't return faster than 10ms.
        """
        mock_db.query.return_value.filter.return_value.first.return_value = None

        with app_ctx.test_request_context("/login", method="POST"):
            from flask import g
            g.correlation_id = "test"
            from app.auth import authenticate_user
            start = time.monotonic()
            user, err = authenticate_user("nobody@example.com", "pass", mock_db)
            elapsed = time.monotonic() - start

        assert user is None
        assert elapsed > 0.01, "bcrypt must run even for unknown users (timing attack)"

    def test_inactive_user_rejected(self, app_ctx, mock_user, mock_db):
        mock_user.is_active = False
        mock_db.query.return_value.filter.return_value.first.return_value = mock_user

        with app_ctx.test_request_context("/login", method="POST"):
            from flask import g
            g.correlation_id = "test"
            from app.auth import authenticate_user
            user, err = authenticate_user("user@example.com", "TestPass1!", mock_db)

        assert user is None
        assert "inactive" in err.lower()


# ============================================================
# Password strength tests
# ============================================================

class TestPasswordStrength:

    def _validate(self, pw):
        from app.routes.auth_bp import _validate_password_strength
        return _validate_password_strength(pw)

    def test_strong_password_passes(self):
        assert self._validate("StrongPass1!") is None

    def test_too_short(self):
        assert self._validate("Short1!") is not None
        assert "12" in self._validate("Short1!")

    def test_over_72_chars(self):
        assert self._validate("A" * 73) is not None

    def test_missing_uppercase(self):
        assert self._validate("alllowercase1!") is not None

    def test_missing_lowercase(self):
        assert self._validate("ALLUPPERCASE1!") is not None

    def test_missing_digit(self):
        assert self._validate("NoDigitsHere!!") is not None

    def test_missing_special(self):
        assert self._validate("NoSpecial1234") is not None

    def test_exactly_12_chars_strong(self):
        assert self._validate("StrongPass1!") is None   # exactly 12

    def test_exactly_72_chars_strong(self):
        pw = "Aa1!" + "a" * 68   # 72 chars total
        assert self._validate(pw) is None


# ============================================================
# Email masking tests (log safety)
# ============================================================

class TestEmailMasking:

    def test_normal_email(self):
        from app.auth import _mask_email
        assert _mask_email("user@example.com") == "u***@example.com"

    def test_single_char_local(self):
        from app.auth import _mask_email
        result = _mask_email("a@b.com")
        assert "***" in result
        assert "a@b.com" not in result   # no full email in logs

    def test_no_at_sign(self):
        from app.auth import _mask_email
        result = _mask_email("notanemail")
        assert result == "***"


# ============================================================
# Cross-tenant isolation tests (integration-level)
# ============================================================

class TestCrossTenantIsolation:
    """
    These tests verify that the require_same_company decorator
    blocks access when company IDs don't match.
    """

    def test_blocks_other_tenant_in_url(self, app):
        from app.auth import Permission, Role, TokenData, permissions_for, require_auth, require_same_company

        @app.route("/api/v1/companies/<int:company_id>/cells")
        @require_auth
        @require_same_company("company_id")
        def list_cells(company_id):
            return "ok", 200

        # Build a JWT for company 7
        import jwt as pyjwt
        from datetime import UTC, datetime, timedelta
        secret = app.config["JWT_SECRET_KEY"]
        csrf   = "csrf-tok"
        payload = {
            "sub": "1", "cid": 7, "rol": "user",
            "csr": csrf, "jti": str(uuid.uuid4()),
            "iat": datetime.now(UTC),
            "exp": datetime.now(UTC) + timedelta(minutes=15),
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        client = app.test_client()
        # Try to access company 99's data with company 7's token
        resp = client.get(
            "/api/v1/companies/99/cells",
            headers={"Cookie": f"erp_access={token}; erp_csrf={csrf}",
                     "X-CSRF-Token": csrf},
        )
        assert resp.status_code == 403

    def test_allows_own_tenant(self, app):
        from app.auth import require_auth, require_same_company

        @app.route("/api/v1/companies/<int:company_id>/widgets")
        @require_auth
        @require_same_company("company_id")
        def list_widgets(company_id):
            return "ok", 200

        import jwt as pyjwt
        from datetime import UTC, datetime, timedelta
        secret = app.config["JWT_SECRET_KEY"]
        csrf   = "csrf-tok2"
        payload = {
            "sub": "1", "cid": 7, "rol": "user",
            "csr": csrf, "jti": str(uuid.uuid4()),
            "iat": datetime.now(UTC),
            "exp": datetime.now(UTC) + timedelta(minutes=15),
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        client = app.test_client()
        resp = client.get(
            "/api/v1/companies/7/widgets",
            headers={"Cookie": f"erp_access={token}; erp_csrf={csrf}",
                     "X-CSRF-Token": csrf},
        )
        assert resp.status_code == 200
