"""
app/routes/auth_bp.py
=====================
Flask Blueprint for authentication endpoints.

Endpoints
---------
POST /api/v1/auth/login       — exchange credentials for tokens (rate-limited)
POST /api/v1/auth/logout      — revoke cookies server-side
POST /api/v1/auth/refresh     — rotate refresh token, issue new access token
GET  /api/v1/auth/me          — return current user profile (auth required)
POST /api/v1/auth/password    — change own password (auth required)

All state-changing endpoints require X-CSRF-Token header (enforced by
@require_auth via the double-submit cookie pattern in auth.py).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from flask import Blueprint, g, jsonify, make_response, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from pydantic import ValidationError

from app.auth import (
    RATE_LOGIN,
    RATE_PASSWORD_RESET,
    RATE_REFRESH,
    Permission,
    Role,
    TokenData,
    authenticate_user,
    clear_auth_cookies,
    current_user,
    hash_password,
    require_auth,
    require_permission,
    rotate_refresh_token,
    set_auth_cookies,
    verify_password,
)
from app.database import get_db

if TYPE_CHECKING:
    pass

logger  = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__, url_prefix="/api/v1/auth")

# ---------------------------------------------------------------------------
# Limiter is created on the app in app/__init__.py and passed here via
# init_app pattern.  The limit decorators below reference it by the module-level
# `limiter` variable which is set in register_auth_blueprint().
# ---------------------------------------------------------------------------
_limiter: Limiter | None = None


def register_auth_blueprint(app, limiter: Limiter) -> None:
    """Register this blueprint and attach the shared limiter."""
    global _limiter
    _limiter = limiter
    app.register_blueprint(auth_bp)


def _rate(limit_string: str):
    """Lazy limit decorator that uses the app-level limiter."""
    def decorator(f):
        if _limiter is not None:
            return _limiter.limit(limit_string)(f)
        return f
    return decorator


# ---------------------------------------------------------------------------
# POST /api/v1/auth/login
# ---------------------------------------------------------------------------

@auth_bp.route("/login", methods=["POST"])
@_rate(RATE_LOGIN)
def login():
    """
    Authenticate with email + password.

    Request body (JSON):
        {
          "email":    "user@example.com",
          "password": "••••••••"
        }

    Success response (200):
        {
          "status":     "ok",
          "user_id":    42,
          "company_id": 7,
          "role":       "manager",
          "csrf_token": "..."   ← also set as erp_csrf cookie (readable by JS)
        }

    The access token and refresh token are set as HTTP-only cookies and
    are NOT present in the response body.
    """
    body = request.get_json(silent=True)
    if not body:
        return jsonify({"error": "Request body must be JSON"}), 400

    email    = body.get("email",    "").strip().lower()
    password = body.get("password", "")

    if not email or not password:
        return jsonify({"error": "email and password are required"}), 422

    if len(email) > 254 or len(password) > 72:
        return jsonify({"error": "Invalid credentials"}), 401

    db = get_db()
    user, error = authenticate_user(email, password, db)

    if error:
        # Generic message — do not reveal whether email exists
        return jsonify({"error": "Invalid credentials"}), 401

    role = Role.from_string(user.role)
    resp = make_response(jsonify({}))  # body filled below after set_auth_cookies

    csrf_token = set_auth_cookies(resp, user.id, user.company_id, role, db)

    resp.data = jsonify({
        "status":     "ok",
        "user_id":    user.id,
        "company_id": user.company_id,
        "role":       user.role,
        "csrf_token": csrf_token,   # convenience — already in cookie
    }).data
    resp.status_code = 200
    return resp


# ---------------------------------------------------------------------------
# POST /api/v1/auth/logout
# ---------------------------------------------------------------------------

@auth_bp.route("/logout", methods=["POST"])
@require_auth
def logout():
    """
    Expire all auth cookies and revoke the refresh token family.

    The @require_auth decorator validates the access token and populates
    g.token_data — including the CSRF check — before this handler runs.
    """
    from app.models import RefreshToken

    td: TokenData = current_user()
    db = get_db()

    # Revoke all active refresh tokens for this user's current session
    # (identified by the family stored in the DB)
    try:
        db.query(RefreshToken).filter(
            RefreshToken.user_id == td.user_id,
            RefreshToken.used    == False,           # noqa: E712
            RefreshToken.revoked == False,           # noqa: E712
            RefreshToken.deleted_at.is_(None),
        ).update({"revoked": True})
        db.commit()
    except Exception as exc:
        logger.error("Failed to revoke refresh tokens on logout: %s", exc)
        db.rollback()

    resp = make_response(jsonify({"status": "ok", "message": "Logged out"}))
    clear_auth_cookies(resp)
    return resp, 200


# ---------------------------------------------------------------------------
# POST /api/v1/auth/refresh
# ---------------------------------------------------------------------------

@auth_bp.route("/refresh", methods=["POST"])
@_rate(RATE_REFRESH)
def refresh():
    """
    Issue a new access token using the refresh token cookie.

    No body required.  No @require_auth — the access token may be expired.
    CSRF is enforced inside rotate_refresh_token() via the refresh-token
    family mechanism rather than the double-submit pattern (the access
    token may be expired so we cannot read its csrf claim).

    Note: The refresh endpoint itself does not carry a CSRF check because
    the refresh cookie is SameSite=Strict and HttpOnly — CSRF cannot read
    or send it cross-origin.  This is the standard OAuth2 refresh pattern.
    """
    db = get_db()
    result, status = rotate_refresh_token(db)

    if status != 200:
        resp = make_response(jsonify(result))
        if status == 401:
            clear_auth_cookies(resp)
        return resp, status

    from app.models import User

    user = db.query(User).filter(
        User.id == result["user_id"],
        User.deleted_at.is_(None),
    ).first()
    if not user:
        return jsonify({"error": "User not found"}), 401

    role = Role.from_string(user.role)
    resp = make_response(jsonify({}))
    csrf_token = set_auth_cookies(resp, user.id, user.company_id, role, db)

    resp.data = jsonify({
        "status":     "ok",
        "csrf_token": csrf_token,
    }).data
    resp.status_code = 200
    return resp


# ---------------------------------------------------------------------------
# GET /api/v1/auth/me
# ---------------------------------------------------------------------------

@auth_bp.route("/me", methods=["GET"])
@require_auth
def me():
    """
    Return the current user's profile and permissions.

    Response (200):
        {
          "user_id":    42,
          "company_id": 7,
          "role":       "manager",
          "permissions": ["entity:read", "entity:create", ...]
        }
    """
    from app.models import User

    td: TokenData = current_user()
    db = get_db()

    user = db.query(User).filter(
        User.id         == td.user_id,
        User.company_id == td.company_id,
        User.deleted_at.is_(None),
    ).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify({
        "user_id":     user.id,
        "company_id":  user.company_id,
        "email":       user.email,
        "display_name": user.display_name,
        "role":        user.role,
        "permissions": sorted(p.value for p in td.permissions),
        "last_login":  user.last_login.isoformat() if user.last_login else None,
    }), 200


# ---------------------------------------------------------------------------
# POST /api/v1/auth/password
# ---------------------------------------------------------------------------

@auth_bp.route("/password", methods=["POST"])
@require_auth
@_rate(RATE_PASSWORD_RESET)
def change_password():
    """
    Change the authenticated user's own password.

    Request body (JSON):
        {
          "current_password": "oldpass",
          "new_password":     "NewPass123!",
          "confirm_password": "NewPass123!"
        }

    Password requirements (server-enforced — not just client-side):
        • 12–72 characters
        • At least one uppercase letter
        • At least one lowercase letter
        • At least one digit
        • At least one special character
    """
    import re

    from app.models import User

    td: TokenData = current_user()
    body = request.get_json(silent=True) or {}

    current_pw = body.get("current_password", "")
    new_pw     = body.get("new_password", "")
    confirm_pw = body.get("confirm_password", "")

    errors: dict[str, str] = {}
    if not current_pw:
        errors["current_password"] = "Required"
    if not new_pw:
        errors["new_password"] = "Required"
    if not confirm_pw:
        errors["confirm_password"] = "Required"
    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 422

    if new_pw != confirm_pw:
        return jsonify({"error": "Validation failed",
                        "fields": {"confirm_password": "Passwords do not match"}}), 422

    pw_errors = _validate_password_strength(new_pw)
    if pw_errors:
        return jsonify({"error": "Validation failed",
                        "fields": {"new_password": pw_errors}}), 422

    db = get_db()
    user = db.query(User).filter(
        User.id == td.user_id, User.deleted_at.is_(None)
    ).first()

    if not user or not verify_password(current_pw, user.password_hash):
        return jsonify({"error": "Current password is incorrect"}), 401

    user.password_hash = hash_password(new_pw)
    db.commit()

    logger.info("Password changed", extra={
        "user_id":       td.user_id,
        "company_id":    td.company_id,
        "correlation_id": g.get("correlation_id"),
    })
    return jsonify({"status": "ok", "message": "Password changed successfully"}), 200


# ---------------------------------------------------------------------------
# Password strength validator (server-side — never rely on client only)
# ---------------------------------------------------------------------------

def _validate_password_strength(password: str) -> str | None:
    """
    Return an error string if the password fails requirements, else None.
    Requirements mirror NIST SP 800-63B recommendations:
        • 12–72 characters (bcrypt hard limit)
        • Mix of character classes
        • Not a common password (Requires Clarification: integrate HaveIBeenPwned API
          or local blocklist — skipped until API policy confirmed)
    """
    import re

    if len(password) < 12:
        return "Password must be at least 12 characters"
    if len(password) > 72:
        return "Password must not exceed 72 characters"
    if not re.search(r"[A-Z]", password):
        return "Password must contain at least one uppercase letter"
    if not re.search(r"[a-z]", password):
        return "Password must contain at least one lowercase letter"
    if not re.search(r"\d", password):
        return "Password must contain at least one digit"
    if not re.search(r"[^A-Za-z0-9]", password):
        return "Password must contain at least one special character"
    return None
